"""
make_paper_figure_1.py - draws Figure 1 of the paper (black and white, 300 dpi),
computed from Equations (1)-(3) for Lomax tails.
Run:  python make_paper_figure_1.py   (needs numpy and matplotlib; writes to the folder newfig)
"""
import os
os.makedirs('newfig', exist_ok=True)
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
GL_X, GL_W = np.polynomial.legendre.leggauss(128)
def _f(xi,s):
    z=1+xi*s; return np.where(z>0, np.exp(-np.log(np.where(z>0,z,1))/xi), 0)
def kappa(p,xi,beta,a,L):
    t=a+(GL_X+1)*L/2; w=GL_W*L/2; s=t/beta; f=_f(xi,s); I0=(w*f).sum(); wv=1+xi*s
    hx=(w*f*(np.log(wv)/xi**2-s/(xi*wv))).sum()/I0; hb=(w*f/wv*s).sum()/I0
    V=(1-p)+(1+xi)*((1+xi)*hx**2-2*hx*hb+2*hb**2); return np.sqrt(V*_f(xi,a/beta))
def lk(xi,qu,qR,m):
    u=((1-qu)**(-xi)-1)/xi; R=((1-qR)**(-xi)-1)/xi
    return kappa(1-qu,xi,1+xi*u,R-u,m*R)
plt.rcParams.update({'font.family':'serif','font.size':9,'axes.titlesize':9.5,'legend.fontsize':8,
 'xtick.labelsize':8,'ytick.labelsize':8,'axes.spines.top':False,'axes.spines.right':False,
 'axes.linewidth':0.6,'lines.linewidth':1.4,'legend.frameon':False,'savefig.bbox':'tight',
 'savefig.pad_inches':0.03,'ps.fonttype':42,'pdf.fonttype':42})
def save(fig,name):
    for ext,kw in (('png',{}),('eps',{}),('pdf',{}),('tif',{'pil_kwargs':{'compression':'tiff_lzw'}})):
        fig.savefig('newfig/%s.%s'%(name,ext),dpi=300,**kw)
    plt.close(fig)

# ---------- Figure 1 ----------
fig,(a,b)=plt.subplots(1,2,figsize=(6.5,2.8))
qR=np.concatenate([np.linspace(0.90,0.99,46),np.linspace(0.9905,0.9995,19)])
Ls=np.geomspace(0.5,10,40)
a.axvspan(0.95,0.99,color='0.88',lw=0,zorder=0)
for xi,ls,col in ((0.3,'-','0.0'),(0.9,'--','0.0'),(1.5,':','0.0')):
    k=[lk(xi,0.8,q,2) for q in qR]
    band=np.array([[lk(xi,0.8,q,m) for m in Ls] for q in qR])
    a.plot(qR,k,ls=ls,color=col,label=r'$\xi = %.1f$'%xi)
    a.plot(qR,band.min(1),ls=ls,color='0.55',lw=0.7)
    a.plot(qR,band.max(1),ls=ls,color='0.55',lw=0.7)
a.set_xlim(0.895,1.0); a.set_ylim(0,2.1)
a.set_xlabel('Retention quantile'); a.set_ylabel(r'$\kappa$')
a.set_title(r'(a) $\kappa$ against retention', loc='left')
a.legend(loc='lower left',title=r'thick: $L=2R$; thin: $L=0.5R$, $10R$',title_fontsize=7)
qu=np.linspace(0.5,0.96,47)
for m,ls,mk in ((0.5,'-','o'),(2,'--','s'),(5,'-.','^'),(10,':','D')):
    b.plot(qu,[lk(0.9,q,0.99,m) for q in qu],ls=ls,color='0.0',marker=mk,markevery=8,
           markerfacecolor='white',markeredgewidth=1,ms=4.5,label=r'$L = %gR$'%m)
b.set_ylim(0,2.1); b.set_xlabel('Threshold quantile'); b.set_ylabel(r'$\kappa$')
b.set_title(r'(b) $\kappa$ against threshold ($\xi = 0.9$, retention 0.99)', loc='left')
b.legend(loc='upper left')
for ax in (a,b):
    ax.grid(axis='y',color='0.9',lw=0.5); ax.set_axisbelow(True)
fig.tight_layout(); save(fig,'Figure1')

print('kappa check', round(float(lk(0.9,0.8,0.99,2)),3), round(float(lk(0.3,0.8,0.95,2)),3))
