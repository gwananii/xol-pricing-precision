# =============================================================================
# xol_figures.py - figures -> xol_figures.zip, tables -> xol_tables.zip,
# then (optionally) delete xol_out\checkpoints.
#
# CRASH-PROOF: every figure is drawn in its OWN separate Python process.
# If drawing one figure crashes, only that figure is skipped (with the reason);
# the notebook kernel is never touched, and the zips are still made.
# Run it with:   !python xol_figures.py
# =============================================================================
import os
for _v in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[_v] = '1'
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['MPLBACKEND'] = 'Agg'

import sys, gc, shutil, zipfile, subprocess, faulthandler, traceback

DELETE_CHECKPOINTS = False                   # set to False to keep xol_out\checkpoints

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(HERE, 'xol_out')
FIG_DIR = os.path.join(HERE, 'xol_figures')
FIG_ZIP = os.path.join(HERE, 'xol_figures.zip')
TAB_ZIP = os.path.join(HERE, 'xol_tables.zip')
FORMATS = ('png', 'pdf', 'eps', 'tif')
FIGURES = ['fig_kappa', 'fig_kappa_body', 'fig_gpd_vs_bc_sim', 'fig_subsampling',
           'fig_bootstrap', 'fig_real_data']


# =============================================================================
# PART A - runs inside a child process: draws ONE figure
# =============================================================================
def draw_one(figname):
    faulthandler.enable()                   # if Python crashes, print where
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    g = globals()
    g['np'], g['pd'], g['plt'] = np, pd, plt

    g.update(DPI=300, WIDTH=6.5, INK='0.10', GRAY='0.45', LIGHT='0.85', REF='0.55',
             MARKERS=['o', 's', '^', 'D', 'v', 'P'], LINES=['-', '--', '-.', ':'],
             REPS_SUB=1000, REPS_BOOT=1000)
    plt.rcParams.update({
        'font.family': 'serif', 'font.size': 9, 'axes.titlesize': 9.5, 'axes.labelsize': 9,
        'legend.fontsize': 8, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
        'axes.spines.top': False, 'axes.spines.right': False, 'axes.linewidth': 0.6,
        'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'lines.linewidth': 1.4,
        'lines.markersize': 5, 'legend.frameon': False, 'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.03, 'ps.fonttype': 42, 'pdf.fonttype': 42})
    g['GL_X'], g['GL_W'] = np.polynomial.legendre.leggauss(128)
    g[figname]()


def grid(ax, axis='y'):
    ax.grid(axis=axis, color='0.9', linewidth=0.5)
    ax.set_axisbelow(True)


def save(fig, name):
    """Save one figure in each format. A format that fails is reported and skipped."""
    for fmt in FORMATS:
        folder = os.path.join(FIG_DIR, fmt)
        os.makedirs(folder, exist_ok=True)
        kw = dict(dpi=DPI)
        if fmt == 'tif':
            kw['pil_kwargs'] = {'compression': 'tiff_lzw'}
        try:
            fig.savefig(os.path.join(folder, '%s.%s' % (name, fmt)), **kw)
            print('    %s.%s' % (name, fmt), flush=True)
        except Exception as e:
            print('    !!! %s.%s not saved: %s: %s' % (name, fmt, type(e).__name__, e), flush=True)
        gc.collect()
    plt.close(fig)


def table(csv_name):
    path = os.path.join(OUT_DIR, csv_name)
    if not os.path.exists(path):
        print('    SKIPPED: %s not found in %s' % (csv_name, OUT_DIR))
        return None
    return pd.read_csv(path)


# -----------------------------------------------------------------------------
# The kappa formula (Equations 1-3), needed for the two analytic figures
# -----------------------------------------------------------------------------
def _f(xi, s):
    z = 1.0 + xi * s
    with np.errstate(invalid='ignore', divide='ignore', over='ignore'):
        out = np.exp(-np.log(np.where(z > 0, z, 1.0)) / xi)
    return np.where(z > 0, out, 0.0)


def kappa(p, xi, beta, a, L):
    """kappa = sqrt(V * S(a)), with V = (1-p) + (1+xi)[(1+xi)h_xi^2 - 2 h_xi h_beta + 2 h_beta^2]."""
    t = a + (GL_X + 1.0) * L / 2.0
    w = GL_W * L / 2.0
    s = t / beta
    f = _f(xi, s)
    I0 = np.sum(w * f)
    wv = 1.0 + xi * s
    hx = np.sum(w * f * (np.log(wv) / xi ** 2 - s / (xi * wv))) / I0
    hb = np.sum(w * f / wv * s) / I0
    V = (1.0 - p) + (1.0 + xi) * ((1.0 + xi) * hx ** 2 - 2.0 * hx * hb + 2.0 * hb ** 2)
    return np.sqrt(V * _f(xi, a / beta))


def lomax_setup(xi, qu, qR, LR):
    u = ((1 - qu) ** (-xi) - 1) / xi
    R = ((1 - qR) ** (-xi) - 1) / xi
    return dict(p=1 - qu, xi=xi, beta=1 + xi * u, a=R - u, L=LR * R, u=u)


def lomax_kappa(xi, qu, qR, LR):
    s = lomax_setup(xi, qu, qR, LR)
    return kappa(s['p'], s['xi'], s['beta'], s['a'], s['L'])


def kappa_body(xi, qu, qR, m, ub):
    a = (((1 - qR) / (1 - qu)) ** (-xi) - 1) / xi
    return kappa(1 - qu, xi, 1.0, a, m * (ub + a))


# -----------------------------------------------------------------------------
# The figures
# -----------------------------------------------------------------------------
def fig_kappa():
    """Figure 1: kappa vs retention quantile (a) and vs threshold quantile (b)."""
    fig, (a, b) = plt.subplots(1, 2, figsize=(WIDTH, 2.7))
    tail = np.logspace(np.log10(0.05), np.log10(1e-4), 60)
    a.axvspan(0.01, 0.05, color=LIGHT, lw=0, zorder=0)
    for i, xi in enumerate((0.5, 0.9, 1.3)):
        col = INK if i != 1 else GRAY
        k = [lomax_kappa(xi, 0.8, 1 - t, 2) for t in tail]
        a.plot(tail, k, color=col, ls=LINES[i], label=r'$\xi$ = %.1f' % xi)
        j = np.argmin(np.abs(tail - 0.01))
        a.plot(tail[j], k[j], marker=MARKERS[i], color=col, ls='none', markerfacecolor='white', markeredgewidth=1)
    a.set_xscale('log')
    a.invert_xaxis()
    a.set_xticks([0.05, 0.01, 0.001, 0.0001])
    a.set_xticklabels(['0.95', '0.99', '0.999', '0.9999'])
    a.set_xlabel('Retention quantile')
    a.set_ylabel(r'$\kappa$')
    a.set_title(r'(a) $L = 2R$, threshold at the 0.8 quantile', loc='left')
    a.legend(loc='upper right')
    grid(a)
    qu = np.linspace(0.5, 0.95, 46)
    for i, m in enumerate((0.5, 2, 5, 10)):
        b.plot(qu, [lomax_kappa(0.9, q, 0.99, m) for q in qu], color=INK if i % 2 == 0 else GRAY,
               ls=LINES[i], marker=MARKERS[i], markevery=9, markerfacecolor='white', markeredgewidth=1,
               label=r'$L = %gR$' % m)
    b.set_xlabel('Threshold quantile')
    b.set_ylabel(r'$\kappa$')
    b.set_title(r'(b) $\xi$ = 0.9, retention at the 0.99 quantile', loc='left')
    b.legend(loc='upper left')
    grid(b)
    fig.tight_layout()
    save(fig, 'fig_kappa')


def fig_kappa_body():
    """Table 3 as a figure: kappa vs u/beta for L = 2R and L = 5R."""
    ub = np.linspace(0, 5, 51)
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 2.5), sharey=True)
    for ax, m in zip(axes, (2, 5)):
        for i, xi in enumerate((0.5, 0.9, 1.3)):
            col = INK if i != 1 else GRAY
            ax.plot(ub, [kappa_body(xi, 0.8, 0.99, m, v) for v in ub], color=col, ls=LINES[i],
                    label=r'$\xi$ = %.1f' % xi)
            s = lomax_setup(xi, 0.8, 0.99, m)
            ul = s['u'] / s['beta']
            ax.plot(ul, kappa_body(xi, 0.8, 0.99, m, ul), marker=MARKERS[i], color=col, ls='none',
                    markerfacecolor='white', markeredgewidth=1)
        ax.set_xlabel(r'$u/\beta$')
        ax.set_title(r'$L = %dR$' % m, loc='left')
        grid(ax)
    axes[0].set_ylabel(r'$\kappa$')
    axes[0].legend(loc='upper left', title='open marker = Lomax', title_fontsize=7)
    fig.tight_layout()
    save(fig, 'fig_kappa_body')


def fig_gpd_vs_bc_sim():
    """Tables 9/S5: relative RMSE of GPD and burning cost against n_R."""
    t = table('table9_S5_gpd_vs_bc.csv')
    if t is None:
        return
    fig, axes = plt.subplots(1, 3, figsize=(WIDTH, 2.5), sharey=True)
    for ax, d in zip(axes, ['Lomax, xi=0.9', 'Burr XII, xi=0.9', 'Lognormal, sigma=1.5']):
        for n, mk in ((500, 'o'), (2000, '^')):
            s = t[(t.dist == d) & (t.n == n)].sort_values('nR')
            ax.plot(s.nR, 100 * s.gpd_rmse, color=INK, ls='-', marker=mk, label='GPD, n = %d' % n)
            ax.plot(s.nR, 100 * s.bc_rmse, color=GRAY, ls='--', marker=mk, markerfacecolor='white',
                    markeredgewidth=1, label='Burning cost, n = %d' % n)
        ax.set_xscale('log')
        ax.set_xticks([1, 5, 20, 100])
        ax.set_xticklabels(['1', '5', '20', '100'])
        ax.set_xlabel(r'Expected losses above $R$, $n_R$')
        ax.set_title(d.replace('xi', r'$\xi$').replace('sigma', r'$\sigma$'), loc='left')
        grid(ax)
    axes[0].set_ylabel('Relative RMSE (%)')
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=4, bbox_to_anchor=(0.5, -0.02))
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    save(fig, 'fig_gpd_vs_bc_sim')


def fig_subsampling():
    """Table 12: (a) spread ratio before/after the FPC; (b) coverage with the FPC."""
    t = table('table12_subsampling.csv')
    if t is None:
        return
    t = t.sort_values(['data', 'n', 'qR']).reset_index(drop=True)
    y = np.arange(len(t))[::-1]
    labels = ['%s, n=%d, q=%.2f' % (r.data, r.n, r.qR) for r in t.itertuples()]
    fig, (a, b) = plt.subplots(1, 2, figsize=(WIDTH, 5.2), sharey=True)
    a.axvspan(0.8, 1.25, color=LIGHT, lw=0, zorder=0)
    a.axvline(1.0, color=REF, lw=0.8)
    for yi, r0, r1 in zip(y, t.ratio, t.ratio_fpc):
        a.plot([r0, r1], [yi, yi], color='0.6', lw=0.8, zorder=1)
    a.plot(t.ratio, y, 'o', color=INK, markerfacecolor='white', markeredgewidth=1, label='Without FPC')
    a.plot(t.ratio_fpc, y, 'o', color=INK, label='With FPC')
    a.set_yticks(y)
    a.set_yticklabels(labels, fontsize=6.5)
    a.set_xlabel('SD of log premium / formula SE')
    a.set_title('(a) Spread against the formula', loc='left')
    a.legend(loc='upper center', bbox_to_anchor=(0.5, -0.09), ncol=2, fontsize=7)
    mcse = np.sqrt(0.09 / REPS_SUB)
    b.axvspan(0.9 - 1.96 * mcse, 0.9 + 1.96 * mcse, color=LIGHT, lw=0, zorder=0)
    b.axvline(0.9, color=REF, lw=0.8)
    for i, ds in enumerate(dict.fromkeys(t.data)):
        s = (t.data == ds).values
        b.plot(t.cov_fpc[s], y[s], MARKERS[i], color=INK if i % 2 == 0 else GRAY,
               markerfacecolor='white' if i >= 2 else None, markeredgewidth=1, ls='none', label=ds)
    b.set_xlabel('Coverage, 90% interval (with FPC)')
    b.set_title('(b) Coverage', loc='left')
    b.legend(loc='upper center', bbox_to_anchor=(0.5, -0.09), ncol=2, fontsize=7)
    for ax in (a, b):
        grid(ax, 'x')
    fig.tight_layout()
    save(fig, 'fig_subsampling')


def fig_bootstrap():
    """Table 18: coverage of the formula, bootstrap and burning-cost intervals."""
    t = table('table18_bootstrap.csv')
    if t is None:
        return
    t = t.sort_values(['n', 'dist']).reset_index(drop=True)
    y = np.arange(len(t))[::-1]
    labels = ['%s, n=%d' % (r.dist.replace('xi', '\u03be').replace('sigma', '\u03c3'), r.n) for r in t.itertuples()]
    mcse = np.sqrt(0.09 / REPS_BOOT)
    fig, ax = plt.subplots(figsize=(WIDTH, 3.0))
    ax.axvspan(0.9 - 1.96 * mcse, 0.9 + 1.96 * mcse, color=LIGHT, lw=0, zorder=0)
    ax.axvline(0.9, color=REF, lw=0.8)
    ax.plot(t.formula_cov, y, 'o', color=INK, label='Formula interval')
    ax.plot(t.boot_cov, y, 's', color=INK, markerfacecolor='white', markeredgewidth=1, label='Percentile bootstrap')
    ax.plot(t.bc_cov, y, '^', color=GRAY, label='Burning cost')
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=7.5)
    ax.set_xlabel('Coverage of nominal 90% interval')
    grid(ax, 'x')
    ax.legend(loc='upper left', bbox_to_anchor=(1.0, 1.0))
    fig.tight_layout()
    save(fig, 'fig_bootstrap_coverage')


def fig_real_data():
    """Table 10: (a) burning cost / GPD premium; (b) relative standard errors."""
    t = table('table10_real_data.csv')
    if t is None:
        return
    y = np.arange(len(t))[::-1]
    fig, (a, b) = plt.subplots(1, 2, figsize=(WIDTH, 3.0), sharey=True)
    a.axvline(1.0, color=REF, lw=0.8)
    a.plot(t.bc_over_gpd, y, 'o', color=INK)
    a.set_yticks(y)
    a.set_yticklabels(['%s (%d)' % (d, k) for d, k in zip(t.dataset, t.obs_above_R)], fontsize=7.5)
    a.set_xlabel('Burning cost / GPD premium')
    a.set_title('(a) Agreement', loc='left')
    for yi, g, c in zip(y, t.gpd_rel_se, t.bc_rel_se):
        b.plot([100 * g, 100 * c], [yi, yi], color='0.6', lw=0.8, zorder=1)
    b.plot(100 * t.gpd_rel_se, y, 'o', color=INK, label='GPD')
    b.plot(100 * t.bc_rel_se, y, 's', color=GRAY, markerfacecolor='white', markeredgewidth=1, label='Burning cost')
    b.set_xlabel('Relative standard error (%)')
    b.set_title('(b) Precision', loc='left')
    b.legend(loc='lower center', bbox_to_anchor=(0.5, 1.08), ncol=2)
    for ax in (a, b):
        grid(ax, 'x')
    fig.text(0.01, 0.005, 'Number of observations above the retention in parentheses.', fontsize=7, color='0.35')
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    save(fig, 'fig_real_data')



# =============================================================================
# PART B - the main run: one child process per figure, then the zips
# =============================================================================
EXIT_REASON = {3221225477: 'access violation in a compiled library (0xC0000005)',
               3221226505: 'a compiled library aborted (0xC0000409)',
               3221226356: 'heap corruption in a compiled library (0xC0000374)',
               3221225781: 'a required DLL was not found (0xC0000135)',
               3221225794: 'a DLL failed to start, possibly blocked by security (0xC0000142)',
               3: 'abort() - often the Intel OpenMP conflict'}


def main():
    print('STEP 1  Figures (each in its own process), tables from', OUT_DIR, flush=True)
    if os.path.isdir(FIG_DIR):
        shutil.rmtree(FIG_DIR)
    os.makedirs(FIG_DIR)
    status = {}
    for name in FIGURES:
        print('  drawing', name, flush=True)
        r = subprocess.run([sys.executable, os.path.abspath(__file__), '--one', name],
                           cwd=HERE, capture_output=True, text=True, encoding='utf8', errors='replace')
        print(r.stdout, end='', flush=True)
        if r.returncode == 0:
            status[name] = 'OK'
        else:
            status[name] = 'FAILED (exit code %s: %s)' % (r.returncode, EXIT_REASON.get(r.returncode, 'see below'))
            print('  !!! %s %s' % (name, status[name]))
            print('\n'.join('      ' + l for l in r.stderr.strip().splitlines()[-15:]), flush=True)
    with open(os.path.join(FIG_DIR, 'README.txt'), 'w') as f:
        f.write('Illustrative figures of the result tables (black-and-white safe).\n'
                'png = preview; pdf, eps, tif = 300 dpi for submission.\n')

    if os.path.exists(FIG_ZIP):
        os.remove(FIG_ZIP)
    n_fig = 0
    with zipfile.ZipFile(FIG_ZIP, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(FIG_DIR):
            for fname in sorted(files):
                full = os.path.join(root, fname)
                z.write(full, os.path.relpath(full, FIG_DIR))
                n_fig += 1
    print('Done: %d files zipped into %s' % (n_fig, FIG_ZIP), flush=True)

    print('\nSTEP 2  Tables', flush=True)
    if os.path.exists(TAB_ZIP):
        os.remove(TAB_ZIP)
    n_tab = 0
    with zipfile.ZipFile(TAB_ZIP, 'w', zipfile.ZIP_DEFLATED) as z:
        for fname in sorted(os.listdir(OUT_DIR)):
            full = os.path.join(OUT_DIR, fname)
            if os.path.isfile(full) and fname.endswith(('.csv', '.txt')) and fname != 'table2_check.csv':
                z.write(full, fname)
                n_tab += 1
    print('Done: %d files zipped into %s' % (n_tab, TAB_ZIP), flush=True)

    ck = os.path.join(OUT_DIR, 'checkpoints')
    if DELETE_CHECKPOINTS and os.path.isdir(ck) and n_tab > 0 and all(v == 'OK' for v in status.values()):
        shutil.rmtree(ck)
        print('\nSTEP 3  Deleted', ck)
    elif os.path.isdir(ck):
        print('\nSTEP 3  Checkpoints kept in', ck)

    print('\nSUMMARY: ' + ', '.join('%s %s' % (k, 'OK' if v == 'OK' else 'FAILED') for k, v in status.items()))
    print('ALL DONE', flush=True)


if __name__ == '__main__':
    if '--one' in sys.argv:
        draw_one(sys.argv[sys.argv.index('--one') + 1])
        sys.stdout.flush(); sys.stderr.flush()
        os._exit(0)          # skip Python's shutdown clean-up, which crashes on this PC
    else:
        main()
