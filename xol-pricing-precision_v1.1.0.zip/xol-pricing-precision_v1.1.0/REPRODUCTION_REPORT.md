# Reproduction notes

Every table and figure of the paper and its online supplement is computed by the code in `code/`, with fixed random seeds, apart from the three items listed at the end. The numbers printed in the paper are those of the run whose output is in `results/` and `figures/`; a second full run gave byte-identical files.

## Choices made where a method needed a precise definition

| Item | Definition used (also stated in the paper) |
|---|---|
| Thresholds in simulated samples (Tables 4, 7, 8, 9, 17, 18, S2, S4) | The (k + 1)th largest observation, with k = round((1 − q)n) |
| Thresholds for real data and for subsamples of real data (Tables 10–16, 19, 13) | Losses strictly above the sample quantile, because these files contain many tied amounts |
| Threshold above the retention | The part of the layer below the threshold is priced with the empirical survival function |
| Grid in Experiment A | Steps of 0.04: 0.50–0.86 (retention 0.90; mid-grid 0.70), 0.60–0.88 (0.95), 0.60–0.92 (0.99) |
| Hill-plateau rule | 60 candidate numbers of exceedances k, evenly spaced on the log scale from max(15, 0.02n) to n/2; the Hill estimate at each; the centre (third candidate) of the window of six consecutive candidates with the smallest coefficient of variation |
| MRL-linear rule | The automated mean-residual-life rule of Langousis et al. (2016, Section 2.2), as in the R function `mev::automrl`, with the same 60 candidates |
| Mixture of Section 6.2 | Spliced: with probability 0.95, a lognormal (σ = 1.5) conditioned to lie below 3; with probability 0.05, a Pareto tail S(x) = 0.05(x/3)^(−1/0.9) above 3 (the split is at the 0.95 quantile) |
| TPW (Supplement S1) | B = 50 bootstrap resamples in the simulations and B = 200 for the real data, reused at every threshold |
| Trimmed TPW (Table S4) | Drop the lowest threshold until ρ ≤ 1, keeping at least three thresholds |

### Why the spliced reading of the mixture

The earlier text ("a 95% lognormal body and a 5% Pareto tail with ξ = 0.9, split at 3") allows two readings. Both were simulated (300 samples per design, thresholds 0.6 and 0.8):

- **Spliced** (lognormal only below 3, Pareto only above): the GPD is misspecified at the 0.6 and 0.8 thresholds, the bias reaches −35% to +25%, and coverage falls to 0.16–0.87 at the 0.8 threshold.
- **Two-component** (lognormal over its whole range with probability 0.95, Pareto above 3 with probability 0.05): the tail is nearly GPD at these thresholds, the bias stays within about 7%, and coverage is 0.88–0.93, including 0.88 at the 0.6 threshold.

The paper uses this design to show what happens when the GPD is wrong at the threshold, so the spliced reading is the one that tests it. The paper now states the definition explicitly, and Table 8, Section 6.2, and Figure 3 report what it gives.

## Not computed by the code

- The descriptive columns of Tables 5 and 6 (periods, currencies, inflation status), taken from the package documentation. The sample sizes and the 0.99 quantiles that set the layers of Table 6 are computed.
- The pilot study in Supplement S5 (the AUC values), which was run with earlier code that is not included; the supplement says so.
- The two mixture rows of the former Table S4 ("Mixture, ξ = 0.8"), whose design was not recorded; they were removed, and Table S4 now has the four Burr and Lomax designs.

## Reference

Langousis, A., A. Mamalakis, M. Puliga, and R. Deidda. 2016. Threshold detection for the generalized Pareto distribution: Review of representative methods and application to the NOAA NCDC daily rainfall database. *Water Resources Research* 52 (4): 2659–2681.
