# =============================================================================
# make_paper_figures_2_3_S1.py - draws Figures 2, 3 and S1 of the paper
#
# Figure 2 : formula against simulated relative RMSE (Lomax), and the error
#            against the expected number of losses above the retention.
# Figure 3 : Experiment A and the simulations of Section 6.2: empirical SD of
#            log premium against the formula SE, and interval coverage.
# Figure S1: naive BMA and TPW weights in the benchmark datasets.
#
# INPUT: xol_out/table7_lomax.csv, xol_out/table8_all_settings.csv,
#        xol_out/table13_designs.csv and xol_out/figureS1_weights.csv,
#        written by  python xol_tables.py --paper --only table7 table8
#        table13 tpw   (this script does no fitting of its own).
# Output: folder paper_figures/ with .png, .pdf, .eps and .tif (300 dpi,
# black and white). Needs numpy, pandas, matplotlib and pillow.
#
# HOW TO RUN
#   Jupyter: paste this whole file into ONE cell and run it.
#   Terminal: python make_paper_figures_2_3_S1.py
#
# CRASH-PROOF: the drawing is done in a separate Python process, so a crash
# in a compiled library cannot stop the Jupyter kernel.
# =============================================================================
import os
import sys
import subprocess

for _v in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[_v] = '1'
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['MPLBACKEND'] = 'Agg'

SCRIPT_NAME = 'make_paper_figures_2_3_S1.py'
OUT_NAME = 'paper_figures'
INPUTS = ['table7_lomax.csv', 'table8_all_settings.csv',
          'table13_designs.csv', 'figureS1_weights.csv']
BENCH = ['Secura', 'Danish', 'Norwegian 1988']


def _script_path():
    """Path of this code as a file. If it was pasted into a notebook cell,
    save the cell's code as a file first, so it can run in its own process."""
    try:
        return os.path.abspath(__file__)
    except NameError:
        pass
    try:
        cell = get_ipython().user_ns['In'][-1]          # this cell's code
    except Exception:
        return None
    lines = [ln for ln in cell.splitlines()
             if not ln.startswith(('%', '!'))]
    path = os.path.join(os.getcwd(), SCRIPT_NAME)
    with open(path, 'w', encoding='utf8') as f:
        f.write('\n'.join(lines) + '\n')
    return path


# =============================================================================
# PART A - runs in the child process
# =============================================================================
def _save(fig, out_dir, name, plt):
    """Save only the figure and format this child process was asked for."""
    if name == _ONLY[0]:
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, name + '.' + _ONLY[1])
        fig.savefig(path, dpi=300)
        print('saved', path, flush=True)
    plt.close(fig)


def draw(out_dir, in_dir):
    import faulthandler
    faulthandler.enable()
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    rd = lambda f: pd.read_csv(os.path.join(in_dir, f))
    plt.rcParams.update({
        'font.family': 'serif', 'font.size': 8.5, 'axes.titlesize': 9,
        'legend.fontsize': 7.5, 'xtick.labelsize': 7.5,
        'ytick.labelsize': 7.5, 'axes.spines.top': False,
        'axes.spines.right': False, 'axes.linewidth': 0.6,
        'lines.linewidth': 1.2, 'legend.frameon': False,
        'savefig.bbox': 'tight', 'savefig.pad_inches': 0.03,
        'ps.fonttype': 42, 'pdf.fonttype': 42})
    marks = ['o', 's', '^', 'D']

    # ---- Figure 2 ---------------------------------------------------------
    t = rd('table7_lomax.csv')
    fig, (a, b) = plt.subplots(1, 2, figsize=(6.5, 2.8))
    for (xi, g), mm in zip(t.groupby('xi'), marks):
        a.plot(g.formula_pct, g.sim_rmse_pct, mm, ms=4.5, color='0.0',
               markerfacecolor='white', label=r'$\xi = %.1f$' % xi)
        b.plot(g.nR, g.sim_rmse_pct, mm, ms=4.5, color='0.0',
               markerfacecolor='white', label=r'$\xi = %.1f$' % xi)
    lim = [0, 1.08 * max(t.formula_pct.max(), t.sim_rmse_pct.max())]
    a.plot(lim, lim, '--', color='0.4', lw=0.8)
    a.set_xlim(lim)
    a.set_ylim(lim)
    a.set_xlabel('Formula relative SE (%)')
    a.set_ylabel('Simulated relative RMSE (%)')
    a.set_title('(a) Formula against simulation', loc='left')
    a.legend(loc='upper left')
    nr = np.geomspace(t.nR.min() * 0.8, t.nR.max() * 1.25, 200)
    b.plot(nr, 110 / np.sqrt(nr), '-', color='0.0', lw=1.0,
           label=r'$1.1/\sqrt{n_R}$')
    b.set_xscale('log')
    b.set_xlabel(r'Expected losses above the retention, $n_R$')
    b.set_ylabel('Simulated relative RMSE (%)')
    b.set_title(r'(b) Error against $n_R$', loc='left')
    b.legend(loc='upper right')
    for ax in (a, b):
        ax.grid(color='0.9', lw=0.5)
        ax.set_axisbelow(True)
    fig.tight_layout()
    _save(fig, out_dir, 'Figure2', plt)

    # ---- Figure 3 ---------------------------------------------------------
    s8 = rd('table8_all_settings.csv')
    ea = rd('table13_designs.csv')
    fig, (a, b) = plt.subplots(1, 2, figsize=(6.5, 2.9))
    a.plot(s8.med_se, s8.sd_log, '.', color='0.65', ms=3,
           label='Simulations (Section 6.2)')
    for (nm, g), mm in zip(ea.groupby('data'), marks):
        a.plot(g.med_se, g.sd_log, mm, ms=4.5, color='0.0',
               markerfacecolor='white', label=nm)
    hi = 1.05 * max(s8.med_se.max(), s8.sd_log.max(), ea.sd_log.max())
    a.plot([0, hi], [0, hi], '--', color='0.3', lw=0.8)
    a.set_xlim(0, hi)
    a.set_ylim(0, hi)
    a.set_xlabel('Median formula SE')
    a.set_ylabel(r'Empirical SD of $\log\hat{\Pi}$')
    a.set_title('(a) Spread', loc='left')
    a.legend(loc='upper left', fontsize=6.5)
    groups = [('Smooth tails', s8[s8.dist != 'Mixture']['cov']),
              ('Mixture', s8[s8.dist == 'Mixture']['cov']),
              ('Real-data\nsubsamples', ea['cov'])]
    rng = np.random.default_rng(0)  # horizontal jitter only
    for i, (lab, v) in enumerate(groups):
        x = i + rng.uniform(-0.15, 0.15, len(v))
        b.plot(x, v, 'o', ms=3, color='0.0', markerfacecolor='white',
               markeredgewidth=0.7)
    b.axhline(0.90, color='0.3', ls='--', lw=0.8)
    b.set_xticks(range(len(groups)))
    b.set_xticklabels([g[0] for g in groups])
    b.set_ylabel('Coverage of nominal 90% interval')
    b.set_title('(b) Coverage', loc='left')
    for ax in (a, b):
        ax.grid(axis='y', color='0.9', lw=0.5)
        ax.set_axisbelow(True)
    fig.tight_layout()
    _save(fig, out_dir, 'Figure3', plt)

    # ---- Figure S1 --------------------------------------------------------
    w = rd('figureS1_weights.csv')
    fig, axes = plt.subplots(1, 3, figsize=(6.5, 2.3))
    for ax, nm in zip(axes, BENCH):
        g = w[w.dataset == nm].sort_values('q')
        x = np.arange(len(g))
        ax.bar(x - 0.2, g.naive_bma, 0.4, color='0.0', label='Naive BMA')
        ax.bar(x + 0.2, g.tpw, 0.4, color='white', edgecolor='0.0',
               hatch='////', lw=0.6, label='TPW')
        H = [-(v[v > 0] * np.log(v[v > 0])).sum()
             for v in (g.naive_bma.values, g.tpw.values)]
        ax.set_title('%s\n$H$ = %.2f (BMA), %.2f (TPW)' % (nm, H[0], H[1]),
                     loc='left', fontsize=8)
        step = max(1, len(g) // 5)
        ax.set_xticks(x[::step])
        ax.set_xticklabels(['%.2f' % q for q in g.q.values[::step]])
        ax.set_xlabel('Threshold quantile')
        ax.set_ylim(0, 1.05)
    axes[0].set_ylabel('Weight')
    axes[0].legend(loc='upper left')
    fig.tight_layout()
    _save(fig, out_dir, 'FigureS1', plt)


# =============================================================================
# PART B - the main run
# =============================================================================
def main():
    script = _script_path()
    if script is None:
        print('Could not save this code as a file. Save it as '
              + SCRIPT_NAME + ' and run:  !python ' + SCRIPT_NAME)
        return
    here = os.path.dirname(script)
    in_dir = os.path.join(here, 'xol_out')
    miss = [f for f in INPUTS if not os.path.exists(os.path.join(in_dir, f))]
    if miss:
        print('Missing %s. First run:  python xol_tables.py --paper --only '
              'table7 table8 table13 tpw' % ', '.join(miss))
        return
    out_dir = os.path.join(here, OUT_NAME)
    print('Drawing Figures 2, 3 and S1 into', out_dir, flush=True)
    names = ('Figure2', 'Figure3', 'FigureS1')
    failed = _run_all(script, out_dir, in_dir, names)
    _finish(script, out_dir, names, failed, 'Figures 2, 3 and S1')


# =============================================================================
# TIFF FILES - made from the saved PNG files in a separate process
# =============================================================================
# The TIFF files are written uncompressed by Pillow's own encoder, which does
# not use the compiled libtiff library (its LZW compression crashed with exit
# code 0xC0000409 on some Windows PCs). Because this runs in its own process,
# a failure here cannot affect the PNG, PDF and EPS files already saved.
def _png_to_tif(pairs):
    """pairs: [png_1, tif_1, png_2, tif_2, ...]"""
    from PIL import Image
    for png, tif in zip(pairs[0::2], pairs[1::2]):
        os.makedirs(os.path.dirname(tif), exist_ok=True)
        with Image.open(png) as im:
            im.convert('L').save(tif, format='TIFF', dpi=(300, 300))
        print('  saved', tif, flush=True)


def _make_tifs(script, pairs):
    """Run _png_to_tif in a child process; True if all TIFFs were saved."""
    if not pairs:
        return True
    r = subprocess.run([sys.executable, script, '--tif'] + list(pairs),
                       capture_output=True, text=True,
                       encoding='utf8', errors='replace')
    print(r.stdout, end='', flush=True)
    if r.returncode != 0:
        print('  !!! TIFF files not made (exit code %s). The PNG, PDF and EPS'
              ' files are complete; EPS is accepted for print.'
              % r.returncode)
        for line in r.stderr.strip().splitlines()[-8:]:
            print('      ' + line)
        return False
    return True


# =============================================================================
# ONE PROCESS PER FILE - each figure in each format is drawn by its own short
# Python process. On some Windows PCs the compiled drawing libraries abort
# (exit code 0xC0000409) when a process goes on drawing after a file has been
# saved; with one file per process, nothing runs after a save, and a failure
# in one file cannot stop the others.
# =============================================================================
_ONLY = [None, None]          # set in the child: (figure name, format)


def _run_all(script, out_dir, in_arg, names):
    """Draw every figure in PNG, PDF and EPS, one process per file.
    Returns the list of files that could not be saved."""
    failed = []
    for n in names:
        for ext in ('png', 'pdf', 'eps'):
            path = os.path.join(out_dir, n + '.' + ext)
            if os.path.exists(path):
                os.remove(path)
            r = subprocess.run(
                [sys.executable, script, '--draw', out_dir, in_arg, n, ext],
                capture_output=True, text=True, encoding='utf8',
                errors='replace')
            # The child prints "saved <path>" only after the file is closed.
            done = ('saved ' + path) in r.stdout and os.path.exists(path)
            if done:
                note = '' if r.returncode == 0 else (
                    '   (process then ended with code %s; file complete)'
                    % r.returncode)
                print('  saved', path + note, flush=True)
            else:
                failed.append(path)
                print('  !!! %s NOT saved (exit code %s)'
                      % (path, r.returncode), flush=True)
                for line in r.stderr.strip().splitlines()[-6:]:
                    print('      ' + line[:200])
    return failed


def _finish(script, out_dir, names, failed, label):
    pairs = []
    for n in names:
        png = os.path.join(out_dir, n + '.png')
        if os.path.exists(png):
            pairs += [png, png[:-4] + '.tif']
    tif_ok = _make_tifs(script, pairs)
    if failed:
        print('PARTLY DONE: %d file(s) not saved (listed above).'
              % len(failed))
    else:
        print('DONE: %s saved as PNG, PDF, EPS%s.'
              % (label, ' and TIFF' if tif_ok else ''))
    try:                                   # preview below the notebook cell
        get_ipython()
        from IPython.display import Image, display
        for n in names:
            png = os.path.join(out_dir, n + '.png')
            if os.path.exists(png):
                display(Image(filename=png, width=800))
    except Exception:
        pass


if __name__ == '__main__':
    if '--tif' in sys.argv:                # child process: TIFF files
        _png_to_tif(sys.argv[sys.argv.index('--tif') + 1 :])
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)
    elif '--draw' in sys.argv:             # child process
        i = sys.argv.index('--draw')
        _ONLY[:] = [sys.argv[i + 3], sys.argv[i + 4]]
        draw(sys.argv[i + 1], sys.argv[i + 2])
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)      # skip the shutdown clean-up that crashes on some PCs
    else:
        main()
