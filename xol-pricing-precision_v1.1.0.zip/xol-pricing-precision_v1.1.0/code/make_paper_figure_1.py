# =============================================================================
# make_paper_figure_1.py - draws Figure 1 of the paper
#
# Figure 1: the constant kappa for Lomax tails, from Equations (1)-(3).
# Output: folder paper_figures/ with Figure1.png, .pdf, .eps and .tif (300 dpi,
# black and white, for print). Needs numpy, matplotlib and pillow.
#
# HOW TO RUN
#   Jupyter: paste this whole file into ONE cell and run it (no other steps).
#   Terminal: python make_paper_figure_1.py
#
# CRASH-PROOF: the drawing is done in a separate Python process, so a crash in
# a compiled library cannot stop the Jupyter kernel. In Jupyter the finished
# figure is shown below the cell.
# =============================================================================
import os
import sys
import subprocess

for _v in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[_v] = '1'
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['MPLBACKEND'] = 'Agg'

SCRIPT_NAME = 'make_paper_figure_1.py'
OUT_NAME = 'paper_figures'


def _script_path():
    """Path of this code as a file. If it was pasted into a notebook cell,
    save the cell's code as a file first, so it can run in its own process."""
    try:
        return os.path.abspath(__file__)
    except NameError:
        pass
    try:
        cell = get_ipython().user_ns['In'][-1]          # this cell's code
    except Exception:
        return None
    # drop notebook commands (%magic, !shell): they start in column 1
    lines = [ln for ln in cell.splitlines()
             if not ln.startswith(('%', '!'))]
    path = os.path.join(os.getcwd(), SCRIPT_NAME)
    with open(path, 'w', encoding='utf8') as f:
        f.write('\n'.join(lines) + '\n')
    return path


# =============================================================================
# PART A - runs in the child process: draw Figure 1
# =============================================================================
def draw(out_dir):
    import faulthandler
    faulthandler.enable()
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    gl_x, gl_w = np.polynomial.legendre.leggauss(128)

    def surv(xi, s):
        """GPD survival (1 + xi s)^(-1/xi); 0 beyond the endpoint."""
        z = 1.0 + xi * s
        with np.errstate(invalid='ignore', divide='ignore', over='ignore'):
            out = np.exp(-np.log(np.where(z > 0, z, 1.0)) / xi)
        return np.where(z > 0, out, 0.0)

    def kappa(p, xi, beta, a, lim):
        """kappa = sqrt(V * S(a)) from Equations (2)-(3)."""
        t = a + (gl_x + 1.0) * lim / 2.0
        w = gl_w * lim / 2.0
        s = t / beta
        f = surv(xi, s)
        i0 = np.sum(w * f)
        wv = 1.0 + xi * s
        hx = np.sum(w * f * (np.log(wv) / xi ** 2 - s / (xi * wv))) / i0
        hb = np.sum(w * f / wv * s) / i0
        v = (1.0 - p) + (1.0 + xi) * ((1.0 + xi) * hx ** 2
                                      - 2.0 * hx * hb + 2.0 * hb ** 2)
        return float(np.sqrt(v * surv(xi, a / beta)))

    def lomax_kappa(xi, q_u, q_r, m):
        """kappa for a Lomax tail: threshold quantile q_u, retention
        quantile q_r, limit L = m * R."""
        u = ((1 - q_u) ** (-xi) - 1) / xi
        r = ((1 - q_r) ** (-xi) - 1) / xi
        return kappa(1 - q_u, xi, 1 + xi * u, r - u, m * r)

    plt.rcParams.update({
        'font.family': 'serif', 'font.size': 9, 'axes.titlesize': 9.5,
        'legend.fontsize': 8, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.linewidth': 0.6, 'lines.linewidth': 1.4,
        'legend.frameon': False, 'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.03, 'ps.fonttype': 42, 'pdf.fonttype': 42})

    fig, (a, b) = plt.subplots(1, 2, figsize=(6.5, 2.8))

    # (a) kappa against the retention quantile, threshold at the 0.8 quantile
    q_r = np.concatenate([np.linspace(0.90, 0.99, 46),
                          np.linspace(0.9905, 0.9995, 19)])
    limits = np.geomspace(0.5, 10, 40)
    a.axvspan(0.95, 0.99, color='0.88', lw=0, zorder=0)
    for xi, style in ((0.3, '-'), (0.9, '--'), (1.5, ':')):
        k = [lomax_kappa(xi, 0.8, q, 2) for q in q_r]
        band = np.array([[lomax_kappa(xi, 0.8, q, m) for m in limits]
                         for q in q_r])
        a.plot(q_r, k, ls=style, color='0.0', label=r'$\xi = %.1f$' % xi)
        a.plot(q_r, band.min(1), ls=style, color='0.55', lw=0.7)
        a.plot(q_r, band.max(1), ls=style, color='0.55', lw=0.7)
    a.set_xlim(0.895, 1.0)
    a.set_ylim(0, 2.1)
    a.set_xlabel('Retention quantile')
    a.set_ylabel(r'$\kappa$')
    a.set_title(r'(a) $\kappa$ against retention', loc='left')
    a.legend(loc='lower left', title_fontsize=7,
             title=r'thick: $L=2R$; thin: $L=0.5R$, $10R$')

    # (b) kappa against the threshold quantile, xi = 0.9, retention 0.99
    q_u = np.linspace(0.5, 0.96, 47)
    for m, style, mark in ((0.5, '-', 'o'), (2, '--', 's'),
                           (5, '-.', '^'), (10, ':', 'D')):
        b.plot(q_u, [lomax_kappa(0.9, q, 0.99, m) for q in q_u],
               ls=style, color='0.0', marker=mark, markevery=8,
               markerfacecolor='white', markeredgewidth=1, ms=4.5,
               label=r'$L = %gR$' % m)
    b.set_ylim(0, 2.1)
    b.set_xlabel('Threshold quantile')
    b.set_ylabel(r'$\kappa$')
    b.set_title(r'(b) $\kappa$ against threshold '
                r'($\xi = 0.9$, retention 0.99)', loc='left')
    b.legend(loc='upper left')

    for ax in (a, b):
        ax.grid(axis='y', color='0.9', lw=0.5)
        ax.set_axisbelow(True)
    fig.tight_layout()

    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, 'Figure1.' + _ONLY[1])
    fig.savefig(path, dpi=300)
    print('saved', path, flush=True)
    plt.close(fig)


# =============================================================================
# PART B - the main run: start the child process, report, preview in Jupyter
# =============================================================================
EXIT_REASON = {
    3221225477: 'access violation in a compiled library (0xC0000005)',
    3221226505: 'a compiled library aborted (0xC0000409)',
    3221226356: 'heap corruption in a compiled library (0xC0000374)',
    3221225781: 'a required DLL was not found (0xC0000135)',
    3: 'abort() - often the Intel OpenMP conflict'}


def main():
    script = _script_path()
    if script is None:
        print('Could not save this code as a file. Save it as '
              + SCRIPT_NAME + ' and run:  !python ' + SCRIPT_NAME)
        return
    out_dir = os.path.join(os.path.dirname(script), OUT_NAME)
    print('Drawing Figure 1 into', out_dir, flush=True)
    failed = _run_all(script, out_dir, '-', ['Figure1'])
    _finish(script, out_dir, ['Figure1'], failed, 'Figure 1')


# =============================================================================
# TIFF FILES - made from the saved PNG files in a separate process
# =============================================================================
# The TIFF files are written uncompressed by Pillow's own encoder, which does
# not use the compiled libtiff library (its LZW compression crashed with exit
# code 0xC0000409 on some Windows PCs). Because this runs in its own process,
# a failure here cannot affect the PNG, PDF and EPS files already saved.
def _png_to_tif(pairs):
    """pairs: [png_1, tif_1, png_2, tif_2, ...]"""
    from PIL import Image
    for png, tif in zip(pairs[0::2], pairs[1::2]):
        os.makedirs(os.path.dirname(tif), exist_ok=True)
        with Image.open(png) as im:
            im.convert('L').save(tif, format='TIFF', dpi=(300, 300))
        print('  saved', tif, flush=True)


def _make_tifs(script, pairs):
    """Run _png_to_tif in a child process; True if all TIFFs were saved."""
    if not pairs:
        return True
    r = subprocess.run([sys.executable, script, '--tif'] + list(pairs),
                       capture_output=True, text=True,
                       encoding='utf8', errors='replace')
    print(r.stdout, end='', flush=True)
    if r.returncode != 0:
        print('  !!! TIFF files not made (exit code %s). The PNG, PDF and EPS'
              ' files are complete; EPS is accepted for print.'
              % r.returncode)
        for line in r.stderr.strip().splitlines()[-8:]:
            print('      ' + line)
        return False
    return True


# =============================================================================
# ONE PROCESS PER FILE - each figure in each format is drawn by its own short
# Python process. On some Windows PCs the compiled drawing libraries abort
# (exit code 0xC0000409) when a process goes on drawing after a file has been
# saved; with one file per process, nothing runs after a save, and a failure
# in one file cannot stop the others.
# =============================================================================
_ONLY = [None, None]          # set in the child: (figure name, format)


def _run_all(script, out_dir, in_arg, names):
    """Draw every figure in PNG, PDF and EPS, one process per file.
    Returns the list of files that could not be saved."""
    failed = []
    for n in names:
        for ext in ('png', 'pdf', 'eps'):
            path = os.path.join(out_dir, n + '.' + ext)
            if os.path.exists(path):
                os.remove(path)
            r = subprocess.run(
                [sys.executable, script, '--draw', out_dir, in_arg, n, ext],
                capture_output=True, text=True, encoding='utf8',
                errors='replace')
            # The child prints "saved <path>" only after the file is closed.
            done = ('saved ' + path) in r.stdout and os.path.exists(path)
            if done:
                note = '' if r.returncode == 0 else (
                    '   (process then ended with code %s; file complete)'
                    % r.returncode)
                print('  saved', path + note, flush=True)
            else:
                failed.append(path)
                print('  !!! %s NOT saved (exit code %s)'
                      % (path, r.returncode), flush=True)
                for line in r.stderr.strip().splitlines()[-6:]:
                    print('      ' + line[:200])
    return failed


def _finish(script, out_dir, names, failed, label):
    pairs = []
    for n in names:
        png = os.path.join(out_dir, n + '.png')
        if os.path.exists(png):
            pairs += [png, png[:-4] + '.tif']
    tif_ok = _make_tifs(script, pairs)
    if failed:
        print('PARTLY DONE: %d file(s) not saved (listed above).'
              % len(failed))
    else:
        print('DONE: %s saved as PNG, PDF, EPS%s.'
              % (label, ' and TIFF' if tif_ok else ''))
    try:                                   # preview below the notebook cell
        get_ipython()
        from IPython.display import Image, display
        for n in names:
            png = os.path.join(out_dir, n + '.png')
            if os.path.exists(png):
                display(Image(filename=png, width=800))
    except Exception:
        pass


if __name__ == '__main__':
    if '--tif' in sys.argv:                # child process: TIFF files
        _png_to_tif(sys.argv[sys.argv.index('--tif') + 1 :])
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)
    elif '--draw' in sys.argv:               # child process
        i = sys.argv.index('--draw')
        _ONLY[:] = [sys.argv[i + 3], sys.argv[i + 4]]
        draw(sys.argv[i + 1])
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)      # skip the shutdown clean-up that crashes on some PCs
    else:
        main()
