import hashlib, os
EXPECTED = {"xol_tables.py": (2346, "900e9fab2fcb54dd"),
            "make_paper_figure_1.py": (282, "6b7a804d4573a055"),
            "xol_figures.py": (543, "90be0744d367e976"),
            "make_paper_figures_4_5.py": (303, "d479d2366603fe80"),
            "make_paper_figures_2_3_S1.py": (317, "4530593424f83a1b")}
for name, (n_ok, fp_ok) in EXPECTED.items():
    if not os.path.exists(name):
        print(f"{name:<24} NOT SAVED YET")
        continue
    lines = open(name, encoding="utf8").read().splitlines()
    fp = hashlib.sha256("\n".join(l.rstrip() for l in lines).encode()).hexdigest()[:16]
    ok = (len(lines) == n_ok and fp == fp_ok)
    print(f"{name:<24} {len(lines):>5} lines   {'OK - complete' if ok else 'DAMAGED - copy this cell again'}")
