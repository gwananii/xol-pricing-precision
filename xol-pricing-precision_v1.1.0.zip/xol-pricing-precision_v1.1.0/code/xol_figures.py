# =============================================================================
# xol_figures.py - illustrative figures of the result tables, zipped
#
# Input:  xol_out/            result tables made by xol_tables.py
# Output: xol_figures/        figures: png (preview), pdf, eps, tif (300 dpi)
#         xol_figures.zip     all figures in one zip
#         xol_tables.zip      all result tables in one zip
#
# HOW TO RUN
#   Jupyter: paste this whole file into ONE cell and run it (no other steps).
#   Terminal: python xol_figures.py
#
# CRASH-PROOF: each figure is drawn in its own Python process, so a crash in a
# compiled library cannot stop the Jupyter kernel; a failed figure is skipped
# with the reason, and both zips are still made. In Jupyter the finished
# figures are shown below the cell.
# =============================================================================
import os
import sys
import gc
import shutil
import zipfile
import subprocess

for _v in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[_v] = '1'
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['MPLBACKEND'] = 'Agg'

# ---- settings -------------------------------------------------------------
DELETE_CHECKPOINTS = False   # True: delete xol_out/checkpoints after success
SHOW_IN_NOTEBOOK = True      # show the PNG figures below the cell in Jupyter

SCRIPT_NAME = 'xol_figures.py'
FORMATS = ('png', 'pdf', 'eps')  # TIFF: made from the PNG files later
FIGURES = ['fig_kappa', 'fig_kappa_body', 'fig_gpd_vs_bc_sim',
           'fig_subsampling', 'fig_bootstrap', 'fig_real_data']


def _script_path():
    """Path of this code as a file. If it was pasted into a notebook cell,
    save the cell's code as a file first, so each figure can run in its
    own process."""
    try:
        return os.path.abspath(__file__)
    except NameError:
        pass
    try:
        cell = get_ipython().user_ns['In'][-1]          # this cell's code
    except Exception:
        return None
    # drop notebook commands (%magic, !shell): they start in column 1
    lines = [ln for ln in cell.splitlines()
             if not ln.startswith(('%', '!'))]
    path = os.path.join(os.getcwd(), SCRIPT_NAME)
    with open(path, 'w', encoding='utf8') as f:
        f.write('\n'.join(lines) + '\n')
    return path


def _folders(here):
    return {'out': os.path.join(here, 'xol_out'),
            'fig': os.path.join(here, 'xol_figures'),
            'fig_zip': os.path.join(here, 'xol_figures.zip'),
            'tab_zip': os.path.join(here, 'xol_tables.zip')}


# =============================================================================
# PART A - runs in a child process: draws ONE figure
# =============================================================================
def draw_one(figname, here):
    """Set up numpy, pandas and matplotlib, then draw the named figure."""
    import faulthandler
    faulthandler.enable()
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    g = globals()
    g.update(np=np, pd=pd, plt=plt, F=_folders(here),
             DPI=300, WIDTH=6.5, INK='0.10', GRAY='0.45', LIGHT='0.85',
             REF='0.55', MARKERS=['o', 's', '^', 'D', 'v', 'P'],
             LINES=['-', '--', '-.', ':'], REPS_SUB=1000, REPS_BOOT=1000)
    g['GL_X'], g['GL_W'] = np.polynomial.legendre.leggauss(128)
    plt.rcParams.update({
        'font.family': 'serif', 'font.size': 9, 'axes.titlesize': 9.5,
        'axes.labelsize': 9, 'legend.fontsize': 8, 'xtick.labelsize': 8,
        'ytick.labelsize': 8, 'axes.spines.top': False,
        'axes.spines.right': False, 'axes.linewidth': 0.6,
        'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
        'lines.linewidth': 1.4, 'lines.markersize': 5,
        'legend.frameon': False, 'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.03, 'ps.fonttype': 42, 'pdf.fonttype': 42})
    g[figname]()


def grid(ax, axis='y'):
    ax.grid(axis=axis, color='0.9', linewidth=0.5)
    ax.set_axisbelow(True)


def save(fig, name):
    """Save a figure in each format; a format that fails is reported."""
    for fmt in FORMATS:
        folder = os.path.join(F['fig'], fmt)
        os.makedirs(folder, exist_ok=True)
        kw = {'dpi': DPI}
        try:
            fig.savefig(os.path.join(folder, name + '.' + fmt), **kw)
            print('    saved %s.%s' % (name, fmt), flush=True)
        except Exception as e:
            print('    !!! %s.%s not saved: %s' % (name, fmt, e), flush=True)
        gc.collect()
    plt.close(fig)


def table(csv_name):
    """Read a result table from xol_out (None if it is missing)."""
    path = os.path.join(F['out'], csv_name)
    if not os.path.exists(path):
        print('    SKIPPED: %s not found (run xol_tables.py first)'
              % csv_name, flush=True)
        return None
    return pd.read_csv(path)


# ---- the kappa formula (Equations 1-3), for the two analytic figures ------
def surv(xi, s):
    """GPD survival (1 + xi s)^(-1/xi); 0 beyond the endpoint."""
    z = 1.0 + xi * s
    with np.errstate(invalid='ignore', divide='ignore', over='ignore'):
        out = np.exp(-np.log(np.where(z > 0, z, 1.0)) / xi)
    return np.where(z > 0, out, 0.0)


def kappa(p, xi, beta, a, lim):
    """kappa = sqrt(V * S(a)) from Equations (2)-(3)."""
    t = a + (GL_X + 1.0) * lim / 2.0
    w = GL_W * lim / 2.0
    s = t / beta
    f = surv(xi, s)
    i0 = np.sum(w * f)
    wv = 1.0 + xi * s
    hx = np.sum(w * f * (np.log(wv) / xi ** 2 - s / (xi * wv))) / i0
    hb = np.sum(w * f / wv * s) / i0
    v = (1.0 - p) + (1.0 + xi) * ((1.0 + xi) * hx ** 2
                                  - 2.0 * hx * hb + 2.0 * hb ** 2)
    return np.sqrt(v * surv(xi, a / beta))


def lomax_setup(xi, q_u, q_r, m):
    u = ((1 - q_u) ** (-xi) - 1) / xi
    r = ((1 - q_r) ** (-xi) - 1) / xi
    return {'p': 1 - q_u, 'xi': xi, 'beta': 1 + xi * u,
            'a': r - u, 'L': m * r, 'u': u}


def lomax_kappa(xi, q_u, q_r, m):
    s = lomax_setup(xi, q_u, q_r, m)
    return kappa(s['p'], s['xi'], s['beta'], s['a'], s['L'])


def kappa_body(xi, q_u, q_r, m, ub):
    a = (((1 - q_r) / (1 - q_u)) ** (-xi) - 1) / xi
    return kappa(1 - q_u, xi, 1.0, a, m * (ub + a))


# ---- the figures ------------------------------------------------------------
def fig_kappa():
    """kappa against the retention quantile (a) and threshold quantile (b)."""
    fig, (a, b) = plt.subplots(1, 2, figsize=(WIDTH, 2.7))
    tail = np.logspace(np.log10(0.05), np.log10(1e-4), 60)
    a.axvspan(0.01, 0.05, color=LIGHT, lw=0, zorder=0)
    for i, xi in enumerate((0.5, 0.9, 1.3)):
        col = INK if i != 1 else GRAY
        k = [lomax_kappa(xi, 0.8, 1 - t, 2) for t in tail]
        a.plot(tail, k, color=col, ls=LINES[i], label=r'$\xi$ = %.1f' % xi)
        j = np.argmin(np.abs(tail - 0.01))
        a.plot(tail[j], k[j], marker=MARKERS[i], color=col, ls='none',
               markerfacecolor='white', markeredgewidth=1)
    a.set_xscale('log')
    a.invert_xaxis()
    a.set_xticks([0.05, 0.01, 0.001, 0.0001])
    a.set_xticklabels(['0.95', '0.99', '0.999', '0.9999'])
    a.set_xlabel('Retention quantile')
    a.set_ylabel(r'$\kappa$')
    a.set_title(r'(a) $L = 2R$, threshold at the 0.8 quantile', loc='left')
    a.legend(loc='upper right')
    grid(a)
    q_u = np.linspace(0.5, 0.95, 46)
    for i, m in enumerate((0.5, 2, 5, 10)):
        b.plot(q_u, [lomax_kappa(0.9, q, 0.99, m) for q in q_u],
               color=INK if i % 2 == 0 else GRAY, ls=LINES[i],
               marker=MARKERS[i], markevery=9, markerfacecolor='white',
               markeredgewidth=1, label=r'$L = %gR$' % m)
    b.set_xlabel('Threshold quantile')
    b.set_ylabel(r'$\kappa$')
    b.set_title(r'(b) $\xi$ = 0.9, retention at the 0.99 quantile',
                loc='left')
    b.legend(loc='upper left')
    grid(b)
    fig.tight_layout()
    save(fig, 'fig_kappa')


def fig_kappa_body():
    """Table 3 as a figure: kappa against u/beta for L = 2R and L = 5R."""
    ub = np.linspace(0, 5, 51)
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 2.5), sharey=True)
    for ax, m in zip(axes, (2, 5)):
        for i, xi in enumerate((0.5, 0.9, 1.3)):
            col = INK if i != 1 else GRAY
            ax.plot(ub, [kappa_body(xi, 0.8, 0.99, m, v) for v in ub],
                    color=col, ls=LINES[i], label=r'$\xi$ = %.1f' % xi)
            s = lomax_setup(xi, 0.8, 0.99, m)
            ul = s['u'] / s['beta']
            ax.plot(ul, kappa_body(xi, 0.8, 0.99, m, ul),
                    marker=MARKERS[i], color=col, ls='none',
                    markerfacecolor='white', markeredgewidth=1)
        ax.set_xlabel(r'$u/\beta$')
        ax.set_title(r'$L = %dR$' % m, loc='left')
        grid(ax)
    axes[0].set_ylabel(r'$\kappa$')
    axes[0].legend(loc='upper left', title='open marker = Lomax',
                   title_fontsize=7)
    fig.tight_layout()
    save(fig, 'fig_kappa_body')


def fig_gpd_vs_bc_sim():
    """Tables 9/S5: relative RMSE of GPD and burning cost against n_R."""
    t = table('table9_S5_gpd_vs_bc.csv')
    if t is None:
        return
    fig, axes = plt.subplots(1, 3, figsize=(WIDTH, 2.5), sharey=True)
    dists = ['Lomax, xi=0.9', 'Burr XII, xi=0.9', 'Lognormal, sigma=1.5']
    for ax, d in zip(axes, dists):
        for n, mk in ((500, 'o'), (2000, '^')):
            s = t[(t.dist == d) & (t.n == n)].sort_values('nR')
            ax.plot(s.nR, 100 * s.gpd_rmse, color=INK, ls='-', marker=mk,
                    label='GPD, n = %d' % n)
            ax.plot(s.nR, 100 * s.bc_rmse, color=GRAY, ls='--', marker=mk,
                    markerfacecolor='white', markeredgewidth=1,
                    label='Burning cost, n = %d' % n)
        ax.set_xscale('log')
        ax.set_xticks([1, 5, 20, 100])
        ax.set_xticklabels(['1', '5', '20', '100'])
        ax.set_xlabel(r'Expected losses above $R$, $n_R$')
        title = d.replace('xi', r'$\xi$').replace('sigma', r'$\sigma$')
        ax.set_title(title, loc='left')
        grid(ax)
    axes[0].set_ylabel('Relative RMSE (%)')
    h, lab = axes[0].get_legend_handles_labels()
    fig.legend(h, lab, loc='lower center', ncol=4,
               bbox_to_anchor=(0.5, -0.02))
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    save(fig, 'fig_gpd_vs_bc_sim')


def fig_subsampling():
    """Table 12: (a) spread ratio before and after the FPC;
    (b) coverage with the FPC."""
    t = table('table12_subsampling.csv')
    if t is None:
        return
    t = t.sort_values(['data', 'n', 'qR']).reset_index(drop=True)
    y = np.arange(len(t))[::-1]
    labels = ['%s, n=%d, q=%.2f' % (r.data, r.n, r.qR)
              for r in t.itertuples()]
    fig, (a, b) = plt.subplots(1, 2, figsize=(WIDTH, 5.2), sharey=True)
    a.axvspan(0.8, 1.25, color=LIGHT, lw=0, zorder=0)
    a.axvline(1.0, color=REF, lw=0.8)
    for yi, r0, r1 in zip(y, t.ratio, t.ratio_fpc):
        a.plot([r0, r1], [yi, yi], color='0.6', lw=0.8, zorder=1)
    a.plot(t.ratio, y, 'o', color=INK, markerfacecolor='white',
           markeredgewidth=1, label='Without FPC')
    a.plot(t.ratio_fpc, y, 'o', color=INK, label='With FPC')
    a.set_yticks(y)
    a.set_yticklabels(labels, fontsize=6.5)
    a.set_xlabel('SD of log premium / formula SE')
    a.set_title('(a) Spread against the formula', loc='left')
    a.legend(loc='upper center', bbox_to_anchor=(0.5, -0.09), ncol=2,
             fontsize=7)
    mcse = np.sqrt(0.09 / REPS_SUB)
    b.axvspan(0.9 - 1.96 * mcse, 0.9 + 1.96 * mcse, color=LIGHT, lw=0,
              zorder=0)
    b.axvline(0.9, color=REF, lw=0.8)
    for i, ds in enumerate(dict.fromkeys(t.data)):
        s = (t.data == ds).values
        b.plot(t.cov_fpc[s], y[s], MARKERS[i],
               color=INK if i % 2 == 0 else GRAY,
               markerfacecolor='white' if i >= 2 else None,
               markeredgewidth=1, ls='none', label=ds)
    b.set_xlabel('Coverage, 90% interval (with FPC)')
    b.set_title('(b) Coverage', loc='left')
    b.legend(loc='upper center', bbox_to_anchor=(0.5, -0.09), ncol=2,
             fontsize=7)
    for ax in (a, b):
        grid(ax, 'x')
    fig.tight_layout()
    save(fig, 'fig_subsampling')


def fig_bootstrap():
    """Table 18: coverage of the formula, bootstrap and burning-cost
    intervals."""
    t = table('table18_bootstrap.csv')
    if t is None:
        return
    t = t.sort_values(['n', 'dist']).reset_index(drop=True)
    y = np.arange(len(t))[::-1]
    labels = []
    for r in t.itertuples():
        d = r.dist.replace('xi', 'ξ').replace('sigma', 'σ')
        labels.append('%s, n=%d' % (d, r.n))
    mcse = np.sqrt(0.09 / REPS_BOOT)
    fig, ax = plt.subplots(figsize=(WIDTH, 3.0))
    ax.axvspan(0.9 - 1.96 * mcse, 0.9 + 1.96 * mcse, color=LIGHT, lw=0,
               zorder=0)
    ax.axvline(0.9, color=REF, lw=0.8)
    ax.plot(t.formula_cov, y, 'o', color=INK, label='Formula interval')
    ax.plot(t.boot_cov, y, 's', color=INK, markerfacecolor='white',
            markeredgewidth=1, label='Percentile bootstrap')
    ax.plot(t.bc_cov, y, '^', color=GRAY, label='Burning cost')
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=7.5)
    ax.set_xlabel('Coverage of nominal 90% interval')
    grid(ax, 'x')
    ax.legend(loc='upper left', bbox_to_anchor=(1.0, 1.0))
    fig.tight_layout()
    save(fig, 'fig_bootstrap_coverage')


def fig_real_data():
    """Table 10: (a) burning cost / GPD premium; (b) relative SEs."""
    t = table('table10_real_data.csv')
    if t is None:
        return
    y = np.arange(len(t))[::-1]
    fig, (a, b) = plt.subplots(1, 2, figsize=(WIDTH, 3.0), sharey=True)
    a.axvline(1.0, color=REF, lw=0.8)
    a.plot(t.bc_over_gpd, y, 'o', color=INK)
    a.set_yticks(y)
    a.set_yticklabels(['%s (%d)' % (d, k)
                       for d, k in zip(t.dataset, t.obs_above_R)],
                      fontsize=7.5)
    a.set_xlabel('Burning cost / GPD premium')
    a.set_title('(a) Agreement', loc='left')
    for yi, g, c in zip(y, t.gpd_rel_se, t.bc_rel_se):
        b.plot([100 * g, 100 * c], [yi, yi], color='0.6', lw=0.8, zorder=1)
    b.plot(100 * t.gpd_rel_se, y, 'o', color=INK, label='GPD')
    b.plot(100 * t.bc_rel_se, y, 's', color=GRAY, markerfacecolor='white',
           markeredgewidth=1, label='Burning cost')
    b.set_xlabel('Relative standard error (%)')
    b.set_title('(b) Precision', loc='left')
    b.legend(loc='lower center', bbox_to_anchor=(0.5, 1.08), ncol=2)
    for ax in (a, b):
        grid(ax, 'x')
    fig.text(0.01, 0.005,
             'Number of observations above the retention in parentheses.',
             fontsize=7, color='0.35')
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    save(fig, 'fig_real_data')


# =============================================================================
# PART B - the main run: one child process per figure, then the zips
# =============================================================================
EXIT_REASON = {
    3221225477: 'access violation in a compiled library (0xC0000005)',
    3221226505: 'a compiled library aborted (0xC0000409)',
    3221226356: 'heap corruption in a compiled library (0xC0000374)',
    3221225781: 'a required DLL was not found (0xC0000135)',
    3: 'abort() - often the Intel OpenMP conflict'}


def _zip_folder(folder, zip_path, only=None):
    """Zip the files in a folder (keeping subfolders). If only is given,
    zip just the top-level files whose names end with those suffixes."""
    if os.path.exists(zip_path):
        os.remove(zip_path)
    n = 0
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(folder):
            if only is not None:
                dirs[:] = []                       # top level only
            for name in sorted(files):
                if only is not None and not name.endswith(only):
                    continue
                full = os.path.join(root, name)
                z.write(full, os.path.relpath(full, folder))
                n += 1
    return n


def _clear_folder(folder):
    """Empty the figure folder; files that are locked (open elsewhere or
    syncing) are reported and overwritten instead of stopping the run."""
    os.makedirs(folder, exist_ok=True)
    for root, _, files in os.walk(folder):
        for name in files:
            try:
                os.remove(os.path.join(root, name))
            except OSError as e:
                print('  note: could not remove %s (%s); it will be '
                      'overwritten' % (name, e.strerror), flush=True)


def _show_pngs(folder):
    """Show the PNG figures below the cell when running in Jupyter."""
    try:
        get_ipython()
        from IPython.display import Image, Markdown, display
    except Exception:
        return
    png_dir = os.path.join(folder, 'png')
    if not os.path.isdir(png_dir):
        return
    for name in sorted(os.listdir(png_dir)):
        if name.endswith('.png'):
            display(Markdown('**' + name + '**'))
            display(Image(filename=os.path.join(png_dir, name), width=800))


def main():
    script = _script_path()
    if script is None:
        print('Could not save this code as a file. Save it as '
              + SCRIPT_NAME + ' and run:  !python ' + SCRIPT_NAME)
        return
    here = os.path.dirname(script)
    f = _folders(here)
    print('Tables read from :', f['out'])
    print('Figures saved in :', f['fig'], flush=True)
    if not os.path.isdir(f['out']):
        print('NOTE: no xol_out folder yet - only the two formula figures '
              'can be drawn. Run xol_tables.py first for the others.')

    print('\nSTEP 1  Figures (each in its own process)', flush=True)
    _clear_folder(f['fig'])
    status = {}
    for name in FIGURES:
        print('  drawing', name, flush=True)
        r = subprocess.run([sys.executable, script, '--one', name, here],
                           capture_output=True, text=True,
                           encoding='utf8', errors='replace')
        print(r.stdout, end='', flush=True)
        if r.returncode == 0:
            status[name] = 'OK'
        else:
            reason = EXIT_REASON.get(r.returncode, 'see the lines below')
            status[name] = 'FAILED'
            print('  !!! %s failed (exit code %s: %s)'
                  % (name, r.returncode, reason))
            for line in r.stderr.strip().splitlines()[-15:]:
                print('      ' + line)
    png_dir = os.path.join(f['fig'], 'png')
    pairs = []
    if os.path.isdir(png_dir):
        for fn in sorted(os.listdir(png_dir)):
            if fn.endswith('.png'):
                pairs += [os.path.join(png_dir, fn),
                          os.path.join(f['fig'], 'tif', fn[:-4] + '.tif')]
    print('  making TIFF files from the PNG files', flush=True)
    _make_tifs(script, pairs)
    with open(os.path.join(f['fig'], 'README.txt'), 'w') as fh:
        fh.write('Illustrative figures of the result tables '
                 '(black-and-white safe).\n'
                 'png = preview; pdf, eps, tif = 300 dpi.\n')
    n_fig = _zip_folder(f['fig'], f['fig_zip'])
    print('Done: %d files zipped into %s' % (n_fig, f['fig_zip']),
          flush=True)

    print('\nSTEP 2  Tables', flush=True)
    n_tab = 0
    if os.path.isdir(f['out']):
        n_tab = _zip_folder(f['out'], f['tab_zip'], only=('.csv', '.txt'))
        print('Done: %d files zipped into %s' % (n_tab, f['tab_zip']))
    else:
        print('Skipped: no xol_out folder.')

    ck = os.path.join(f['out'], 'checkpoints')
    all_ok = all(v == 'OK' for v in status.values())
    if DELETE_CHECKPOINTS and os.path.isdir(ck) and n_tab and all_ok:
        shutil.rmtree(ck, ignore_errors=True)
        print('\nSTEP 3  Deleted', ck)

    print('\nSUMMARY: ' + ', '.join('%s %s' % kv for kv in status.items()))
    print('ALL DONE', flush=True)
    if SHOW_IN_NOTEBOOK:
        _show_pngs(f['fig'])


# =============================================================================
# TIFF FILES - made from the saved PNG files in a separate process
# =============================================================================
# The TIFF files are written uncompressed by Pillow's own encoder, which does
# not use the compiled libtiff library (its LZW compression crashed with exit
# code 0xC0000409 on some Windows PCs). Because this runs in its own process,
# a failure here cannot affect the PNG, PDF and EPS files already saved.
def _png_to_tif(pairs):
    """pairs: [png_1, tif_1, png_2, tif_2, ...]"""
    from PIL import Image
    for png, tif in zip(pairs[0::2], pairs[1::2]):
        os.makedirs(os.path.dirname(tif), exist_ok=True)
        with Image.open(png) as im:
            im.convert('L').save(tif, format='TIFF', dpi=(300, 300))
        print('  saved', tif, flush=True)


def _make_tifs(script, pairs):
    """Run _png_to_tif in a child process; True if all TIFFs were saved."""
    if not pairs:
        return True
    r = subprocess.run([sys.executable, script, '--tif'] + list(pairs),
                       capture_output=True, text=True,
                       encoding='utf8', errors='replace')
    print(r.stdout, end='', flush=True)
    if r.returncode != 0:
        print('  !!! TIFF files not made (exit code %s). The PNG, PDF and EPS'
              ' files are complete; EPS is accepted for print.'
              % r.returncode)
        for line in r.stderr.strip().splitlines()[-8:]:
            print('      ' + line)
        return False
    return True


if __name__ == '__main__':
    if '--tif' in sys.argv:                # child process: TIFF files
        _png_to_tif(sys.argv[sys.argv.index('--tif') + 1 :])
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)
    elif '--one' in sys.argv:                     # child process
        i = sys.argv.index('--one')
        draw_one(sys.argv[i + 1], sys.argv[i + 2])
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)      # skip the shutdown clean-up that crashes on some PCs
    else:
        main()
