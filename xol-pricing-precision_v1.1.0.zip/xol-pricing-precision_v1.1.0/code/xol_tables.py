"""
xol_tables.py  -  complete code, from downloading the data to the result tables
===============================================================================

Paper: "How Precisely Can an Excess-of-Loss Layer Be Priced?
        A Precision Rule for Peaks-over-Threshold Premiums"

This single file is all you need. It does not import or call any other code
    file.
It uses only numpy, pandas and rdata (plus Python's standard library). It does
    NOT
use scipy, matplotlib, background processes or parallel threads, which are the
    usual
causes of crashes in Anaconda on Windows laptops.

Built to run safely on an ordinary laptop (for example a Dell with 8 GB of
    memory):
  * one maths thread only, and the memory use stays below about 0.5 GB;
  * every table is SAVED AS IT GOES (checkpoints). If the run stops for any
      reason
    (crash, closed window, sleep, power), simply start it again: it continues
        where it
    stopped and gives exactly the same numbers as an uninterrupted run;
  * if Python itself crashes, the reason is written to
      xol_out/crash_report.txt.

-------------------------------------------------------------------------------
HOW TO RUN  (keep this file in a folder of your choice, e.g. C:\\work)
-------------------------------------------------------------------------------
Packages (once):   pip install numpy pandas rdata

BEST - run outside Jupyter, in the "Anaconda Prompt" (Start menu -> Anaconda
    Prompt):
    cd C:\\work
    python xol_tables.py              quick test of everything (about 2-3
        minutes)
    python xol_tables.py --paper      the paper's settings (about 1-4
        hours)
    python xol_tables.py --paper --only table18      one table only
    python xol_tables.py --paper --fresh             ignore saved progress,
        start over

In a Jupyter notebook (the code runs in its own process, so the notebook cannot
    die):
    !python xol_tables.py
    !python xol_tables.py --paper

Or inside the notebook itself:
    import xol_tables as xt
    xt.run(quick=True)                # quick test
    xt.run(quick=False)               # paper settings
    xt.run(quick=False, only=['table12'])

Tables (steps): table2, table3 (also gives Table C1), table10, table14
    (Tables 14, 15, 16), table11 (Tables 11 and 19, and the input file of
    make_paper_figures_4_5.py), table12, table9 (also gives Table 4 and
    Table S5), table18, table1 (Tables 1, 5 and 6), table7, table8,
    table13, table17 (Table 17 and Table S2), tpw (Tables S1 and S3),
    tableS4

Outputs, in the same folder as this file:
    xol_data/                 the 12 downloaded data files
    xol_out/*.csv             every result table
    xol_out/all_tables.txt    all tables in one readable text file
    xol_out/run_log.txt       everything printed on screen
    xol_out/checkpoints/      saved progress (delete it, or use --fresh, to
        start over)
    xol_out/crash_report.txt  only written if Python itself crashes
-------------------------------------------------------------------------------
"""

# =============================================================================
# 0. SAFE ENVIRONMENT - these lines must come BEFORE numpy is imported
# =============================================================================
import os

for _v in (
    'OMP_NUM_THREADS',
    'MKL_NUM_THREADS',
    'OPENBLAS_NUM_THREADS',
    'NUMEXPR_NUM_THREADS',
):
    os.environ[_v] = '1'  # one thread: less memory, no thread crashes
os.environ['KMP_DUPLICATE_LIB_OK'] = (
    'TRUE'  # avoids "OMP: Error #15" in Anaconda on Windows
)

import sys
import gc
import math
import time
import pickle
import platform
import statistics
import faulthandler
import traceback
import urllib.request
import warnings

import numpy as np
import pandas as pd

try:
    import rdata  # pure-Python reader for R data files
except ImportError:
    sys.exit(
        "The package 'rdata' is missing. Install it with:  pip install rdata"
    )

warnings.filterwarnings('ignore', message='Missing constructor for R class')

# =============================================================================
# 1. SETTINGS
# =============================================================================
try:
    HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:  # code pasted into a notebook cell
    HERE = os.getcwd()

DATA_DIR = os.path.join(HERE, 'xol_data')
OUT_DIR = os.path.join(HERE, 'xol_out')
CK_DIR = os.path.join(OUT_DIR, 'checkpoints')
LOG_FILE = os.path.join(OUT_DIR, 'run_log.txt')
CRASH_FILE = os.path.join(OUT_DIR, 'crash_report.txt')

# Replication counts: the paper's settings, and a quick test.
PAPER = dict(
    reps_bc=5000, reps_sub=1000, reps_boot=1000, B_boot=999, B_real=200,
    reps_lomax=1500, reps_beyond=600, reps_expA=300, reps_avg=500, B_avg=50,
    B_tpw=200, reps_trim=300,
)
QUICK = dict(
    reps_bc=300, reps_sub=100, reps_boot=30, B_boot=199, B_real=50,
    reps_lomax=100, reps_beyond=60, reps_expA=30, reps_avg=20, B_avg=20,
    B_tpw=30, reps_trim=10,
)

# Random seeds (fixed, so every run with --paper gives the same numbers).
SEED_BC, SEED_SUB, SEED_BOOT_300, SEED_BOOT_1000 = (
    777,
    4242,
    20261122,
    20261121,
)
SEED_REAL = 20261124  # bootstrap of Tables 11 and 19

# Memory control: GPD fits are done in batches with at most this many
# (samples x exceedances). Lower it (e.g. 5_000) if memory is very tight.
# The results do not depend on this number.
GPD_FIT_BATCH = 20_000

# Simulated samples are generated in chunks of this many rows (results
# unchanged).
SIM_CHUNK = 250

# How often (in replications) the bootstrap study saves its progress.
BOOT_SAVE_EVERY = 20

# The 12 public data files (ReIns, fitdistrplus and CASdatasets on GitHub).
_RAW = 'https://raw.githubusercontent.com/'
FILES = {
    'secura.RData': _RAW + 'TReynkens/ReIns/master/data/secura.RData',
    'norwegianfire.RData': _RAW
    + 'TReynkens/ReIns/master/data/norwegianfire.RData',
    'danishuni.rda': _RAW
    + 'lbbe-software/fitdistrplus/master/data/danishuni.rda',
}
for _name in (
    'freMTPL2sev',
    'freMTPLsev',
    'fremarine',
    'usautoBI',
    'frecomfire',
    'frebiloss',
    'lossalae',
    'lossalaefull',
    'ausautoBI8999',
):
    FILES[_name + '.rda'] = (
        _RAW + 'dutangc/CASdatasets/master/data/%s.rda' % _name
    )

# Layers priced in the paper: dataset -> (retention R, limit L).
BENCH = {
    'Secura': (2e6, 3e6),
    'Danish': (10.0, 40.0),
    'Norwegian 1988': (5000.0, 10000.0),
}
EXTRA = {
    'freMTPL2sev': (16500, 33000),
    'freMTPLsev': (16100, 32200),
    'fremarine': (385, 770),
    'usautoBI': (67.8, 135.6),
    'frecomfire': (92.3e6, 184.6e6),
    'frebiloss': (10.9e6, 21.8e6),
    'ausautoBI8999': (394000, 788000),
}

# GPD threshold quantile for Table 10 (mid-grid for the benchmarks, 0.76
# otherwise).
THRESHOLD_Q = {'Secura': 0.40, 'Danish': 0.88, 'Norwegian 1988': 0.80}

pd.set_option('display.width', 220)
pd.set_option('display.max_columns', 40)
pd.set_option('display.max_rows', 200)


# =============================================================================
# 2. SMALL HELPERS: printing, logging, saving, checkpoints
# =============================================================================
_CRASH_HANDLE = None


def _prepare_folders():
    """Create the output folders and switch on the crash recorder."""
    global _CRASH_HANDLE
    for folder in (DATA_DIR, OUT_DIR, CK_DIR):
        os.makedirs(folder, exist_ok=True)
    if _CRASH_HANDLE is None:
        try:
            _CRASH_HANDLE = open(CRASH_FILE, 'a')
            faulthandler.enable(
                file=_CRASH_HANDLE
            )  # records hard crashes of Python
        except Exception:
            pass


def say(text=''):
    """Print a line immediately and add it to run_log.txt."""
    print(text, flush=True)
    try:
        with open(LOG_FILE, 'a', encoding='utf8') as f:
            f.write(str(text) + '\n')
    except OSError:
        pass


def show(df, title, csv_name, digits=4):
    """Print a table, save it as CSV and append it to all_tables.txt."""
    text = df.round(digits).to_string(index=False)
    say('\n' + title)
    say(text)
    df.to_csv(os.path.join(OUT_DIR, csv_name), index=False)
    with open(
        os.path.join(OUT_DIR, 'all_tables.txt'), 'a', encoding='utf8'
    ) as f:
        f.write('\n%s\n%s\n' % (title, text))


class Checkpoint:
    """Saved progress of one table. Everything (including the state of the
    random
    number generator) is written to disk, so an interrupted run continues
    exactly
    where it stopped and gives the same numbers."""

    def __init__(self, name, quick, fresh=False):
        self.path = os.path.join(
            CK_DIR, '%s_%s.pkl' % (name, 'quick' if quick else 'paper')
        )
        self.data = {}
        if fresh and os.path.exists(self.path):
            os.remove(self.path)
        if os.path.exists(self.path):
            try:
                with open(self.path, 'rb') as f:
                    self.data = pickle.load(f)
                say(
                    '  (continuing from saved progress: %s)'
                    % os.path.basename(self.path)
                )
            except Exception:
                self.data = {}  # damaged file: start this table again

    def get(self, key, default=None):
        return self.data.get(key, default)

    def put(self, key, value):
        self.data[key] = value

    def save(self):
        tmp = self.path + '.tmp'
        with open(tmp, 'wb') as f:
            pickle.dump(self.data, f, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(tmp, self.path)  # atomic: never leaves half a file


def _rng_from(state_or_seed):
    """A random generator from a seed, or restored from a saved state."""
    rng = np.random.default_rng(0)
    if isinstance(state_or_seed, dict):
        rng.bit_generator.state = state_or_seed
    else:
        rng = np.random.default_rng(state_or_seed)
    return rng


# =============================================================================
# 3. DATA: download and load
# =============================================================================
def download_data():
    """Download any data file that is not yet in xol_data (about 30 MB in
    total).
    """
    _prepare_folders()
    for fname, url in FILES.items():
        path = os.path.join(DATA_DIR, fname)
        if os.path.exists(path) and os.path.getsize(path) > 0:
            continue
        say('  downloading %s' % fname)
        try:
            urllib.request.urlretrieve(url, path + '.part')
            os.replace(path + '.part', path)
        except Exception as e:
            raise RuntimeError(
                'Could not download %s (%s).\nDownload it by hand from\n  %s\n'
                'and put it in %s' % (fname, e, url, DATA_DIR)
            )
    say('  data folder: %s (all %d files present)' % (DATA_DIR, len(FILES)))


def read_r(fname):
    """Read the data frame stored in an .rda / .RData file."""
    path = os.path.join(DATA_DIR, fname)
    if not os.path.exists(path):
        download_data()
    return list(rdata.read_rda(path).values())[0]


def load(name):
    """Strictly positive claim amounts of a dataset, as a numpy array."""
    if name == 'Secura':
        x = read_r('secura.RData')['size'].to_numpy(float)
    elif name == 'Danish':
        x = read_r('danishuni.rda')['Loss'].to_numpy(float)
    elif name == 'Norwegian 1988':
        d = read_r('norwegianfire.RData')
        x = d.loc[d['year'] == 88, 'size'].to_numpy(float)
    else:
        col = {
            'freMTPL2sev': 'ClaimAmount',
            'freMTPLsev': 'ClaimAmount',
            'fremarine': 'ClaimPaid',
            'usautoBI': 'LOSS',
            'frecomfire': 'ClaimCost',
            'frebiloss': 'ClaimCost',
            'lossalae': 'Loss',
            'ausautoBI8999': 'AggClaim',
        }[name]
        x = read_r(name + '.rda')[col].to_numpy(float)
    x = x[np.isfinite(x)]
    return x[x > 0]


# =============================================================================
# 4. CORE FORMULAS: layer premium, derivatives, V, kappa, GPD fit, burning cost
# =============================================================================
GL_X, GL_W = np.polynomial.legendre.leggauss(
    128
)  # Gauss-Legendre nodes, layer integral


def _nodes(a, L):
    return a + (GL_X + 1.0) * L / 2.0, GL_W * L / 2.0


def _f(xi, s):
    """GPD survival (1 + xi s)^(-1/xi); exp(-s) when xi = 0; 0 beyond the
    endpoint (xi < 0).
    """
    if abs(xi) < 1e-8:
        return np.exp(-s)
    z = 1.0 + xi * s
    with np.errstate(invalid='ignore', divide='ignore', over='ignore'):
        out = np.exp(-np.log(np.where(z > 0, z, 1.0)) / xi)
    return np.where(z > 0, out, 0.0)


def premium(p, xi, beta, a, L):
    """Equation (1): Pi = p * int_a^{a+L} (1 + xi t / beta)^(-1/xi) dt, with p
    the
    exceedance proportion, a = R - u and L the layer limit."""
    t, w = _nodes(a, L)
    return p * np.sum(w * _f(xi, t / beta))


def h_terms(xi, beta, a, L):
    """Appendix B: h_xi = d log Pi / d xi and h_beta = d log Pi / d log beta.
    """
    t, w = _nodes(a, L)
    s = t / beta
    f = _f(xi, s)
    I0 = np.sum(w * f)
    pos = 1.0 + xi * s > 0
    wv = np.where(pos, 1.0 + xi * s, 1.0)
    if abs(xi) < 1e-6:
        dxi = f * s**2 / 2.0
    else:
        dxi = f * (np.log(wv) / xi**2 - s / (xi * wv))
    dlb = f / wv * s
    return np.sum(w * dxi) / I0, np.sum(w * dlb) / I0


def V_term(p, xi, beta, a, L, poisson=False):
    """Equation (2): V = (1 - p) + (1+xi)[(1+xi) h_xi^2 - 2 h_xi h_beta + 2
    h_beta^2].
    With poisson=True the count term is 1 (Corollary 2, Poisson claim counts).
    """
    hx, hb = h_terms(xi, beta, a, L)
    count = 1.0 if poisson else (1.0 - p)
    return count + (1.0 + xi) * (
        (1.0 + xi) * hx**2 - 2.0 * hx * hb + 2.0 * hb**2
    )


def kappa(p, xi, beta, a, L, poisson=False):
    """Equation (3): relative SE = kappa / sqrt(n_R)."""
    return np.sqrt(V_term(p, xi, beta, a, L, poisson) * _f(xi, a / beta))


def rel_se(nu, p, xi, beta, a, L):
    """First-order relative standard error of the premium, sqrt(V / n_u)."""
    return np.sqrt(V_term(p, xi, beta, a, L) / nu)


def lomax_q(q, xi):
    return ((1.0 - q) ** (-xi) - 1.0) / xi


def lomax_setup(xi, qu, qR, LR):
    """GPD parameters above the threshold for a Lomax tail (threshold quantile
    qu,
    retention quantile qR, limit L = LR * R)."""
    u, R = lomax_q(qu, xi), lomax_q(qR, xi)
    return dict(
        p=1.0 - qu, xi=xi, beta=1.0 + xi * u, a=R - u, L=LR * R, u=u, R=R
    )


def lomax_kappa(xi, qu, qR, LR, poisson=False):
    s = lomax_setup(xi, qu, qR, LR)
    return kappa(s['p'], s['xi'], s['beta'], s['a'], s['L'], poisson)


def _profile(theta, Y):
    """GPD profile log-likelihood per observation, in theta = xi / beta."""
    lg = np.log1p(theta[..., None] * Y[:, None, :])
    xi = lg.mean(-1)
    del lg
    with np.errstate(divide='ignore', invalid='ignore'):
        beta = np.where(np.abs(theta) > 1e-12, xi / theta, Y.mean(-1)[:, None])
        ll = -np.log(beta) - xi - 1.0
    ll = np.where(np.isfinite(ll) & (beta > 0), ll, -np.inf)
    return ll, xi, beta


def _gpd_fit_block(Y):
    r = Y.shape[0]
    lo = -0.999 / Y.max(1)  # theta must exceed -1 / max(y)
    ybar = Y.mean(1)
    tn = np.linspace(-0.999, -1e-4, 30)
    tp = np.logspace(-4, 6, 120)
    theta = np.concatenate(
        [(-tn)[None, :] * lo[:, None], tp[None, :] / ybar[:, None]], axis=1
    )
    ll, _, _ = _profile(theta, Y)
    j = np.argmax(ll, 1)
    m = theta.shape[1]
    A = theta[np.arange(r), np.clip(j - 1, 0, m - 1)]
    B = theta[np.arange(r), np.clip(j + 1, 0, m - 1)]
    del ll, theta
    g = (np.sqrt(5) - 1) / 2
    for _ in range(60):  # golden-section refinement
        c, d = B - g * (B - A), A + g * (B - A)
        left = (
            _profile(c[:, None], Y)[0][:, 0] > _profile(d[:, None], Y)[0][:, 0]
        )
        B, A = np.where(left, d, B), np.where(left, A, c)
    _, xi, beta = _profile(((A + B) / 2)[:, None], Y)
    return xi[:, 0], beta[:, 0], (j == 0).astype(int)


def gpd_fit(Y):
    """GPD maximum-likelihood fit for each ROW of Y (excesses over the
    threshold).
    Returns arrays xi, beta, flag (flag = 1: maximum on the lower search
    boundary).
    """
    Y = np.atleast_2d(np.asarray(Y, float))
    rows = max(1, GPD_FIT_BATCH // Y.shape[1])
    if Y.shape[0] <= rows:
        return _gpd_fit_block(Y)
    parts = [
        _gpd_fit_block(Y[i : i + rows]) for i in range(0, Y.shape[0], rows)
    ]
    return tuple(np.concatenate([part[j] for part in parts]) for j in range(3))


def premium_vec(p, xi, beta, a, L):
    """Layer premium for arrays xi, beta, a (one value per bootstrap resample).
    """
    t = a[:, None] + (GL_X[None, :] + 1.0) * L / 2.0
    s = t / beta[:, None]
    x = xi[:, None]
    small = np.abs(x) < 1e-8
    z = 1.0 + np.where(small, 0, x) * s
    with np.errstate(invalid='ignore', divide='ignore', over='ignore'):
        g = np.exp(-np.log(np.where(z > 0, z, 1.0)) / np.where(small, 1, x))
    f = np.where(small, np.exp(-s), np.where(z > 0, g, 0.0))
    return p * (f * (GL_W * L / 2.0)).sum(1)


def empirical_premium(x, R, L):
    """Burning cost: mean of min((X - R)+, L) per loss, and its relative SE."""
    pay = np.clip(x - R, 0.0, L)
    m = pay.mean()
    se = pay.std(ddof=1) / np.sqrt(len(x))
    return m, (se / m if m > 0 else np.nan)


def fitq(x, q, R, L):
    """GPD fit with the threshold at the sample q-quantile; premium and
    relative SE.
    """
    u = np.quantile(x, q)
    y = x[x > u] - u
    xi, b, f = gpd_fit(y[None, :])
    xi, b, p = xi[0], b[0], len(y) / len(x)
    return dict(
        u=u,
        k=len(y),
        xi=xi,
        beta=b,
        Pi=premium(p, xi, b, R - u, L),
        rse=rel_se(len(y), p, xi, b, R - u, L),
        flag=int(f[0]),
    )


def rmse(e):
    return np.sqrt(np.mean(e**2))


# =============================================================================
# 5. LOSS DISTRIBUTIONS FOR THE SIMULATIONS (no scipy needed)
# =============================================================================
_N01 = statistics.NormalDist()
_erfc = np.frompyfunc(math.erfc, 1, 1)
GL16_X, GL16_W = np.polynomial.legendre.leggauss(16)


class Lomax:
    """GPD from zero with scale 1 and shape xi."""

    def __init__(self, xi):
        self.xi = xi
        self.name = 'Lomax, xi=%g' % xi

    def sf(self, x):
        return (1 + self.xi * x) ** (-1 / self.xi)

    def q(self, p):
        return ((1 - p) ** (-self.xi) - 1) / self.xi

    def rvs(self, rng, size):
        return self.q(rng.random(size))


class Burr:
    """Burr XII with survival (1 + x^c)^(-k), tail index xi = 1/(c k), c = 2.
    """

    def __init__(self, xi, c=2.0):
        self.c = c
        self.k = 1.0 / (xi * c)
        self.name = 'Burr XII, xi=%g' % xi

    def sf(self, x):
        return (1 + x**self.c) ** (-self.k)

    def q(self, p):
        return ((1 - p) ** (-1 / self.k) - 1) ** (1 / self.c)

    def rvs(self, rng, size):
        return self.q(rng.random(size))


class LogNormal:
    """Lognormal with log-mean 0 and log-standard deviation sigma."""

    def __init__(self, sigma):
        self.s = sigma
        self.name = 'Lognormal, sigma=%g' % sigma

    def sf(self, x):
        return 0.5 * _erfc(
            np.log(np.asarray(x, float)) / (self.s * math.sqrt(2))
        ).astype(float)

    def q(self, p):
        return math.exp(self.s * _N01.inv_cdf(p))

    def rvs(self, rng, size):
        return np.exp(self.s * rng.standard_normal(size))


def true_premium(d, R, L, panels=200):
    """True layer premium int_R^{R+L} S(x) dx, by composite 16-point Gauss-
    Legendre
    (relative accuracy about 1e-13 for these smooth survival functions)."""
    edges = np.linspace(R, R + L, panels + 1)
    mid, half = (edges[1:] + edges[:-1]) / 2, (edges[1:] - edges[:-1]) / 2
    x = (mid[:, None] + half[:, None] * GL16_X[None, :]).ravel()
    w = (half[:, None] * GL16_W[None, :]).ravel()
    return float(np.sum(w * d.sf(x)))


# =============================================================================
# 6. THE TABLES
# =============================================================================
def table2_checks(cfg, quick, fresh):
    """Table 2 (kappa for Lomax tails) plus checks of the derivatives and the
    GPD fit.
    """
    tab2 = pd.DataFrame(
        [
            [qR, xi]
            + [float(lomax_kappa(xi, 0.8, qR, m)) for m in (0.5, 1, 2, 5, 10)]
            for qR in (0.95, 0.99)
            for xi in (0.2, 0.5, 0.9, 1.3, 2.0)
        ],
        columns=[
            'retention_q',
            'xi',
            'L=0.5R',
            'L=R',
            'L=2R',
            'L=5R',
            'L=10R',
        ],
    )
    show(
        tab2,
        'TABLE 2  kappa, Lomax tails, threshold at the 0.8 quantile',
        'table2.csv',
        2,
    )

    p, b, a, L = 0.2, 1.3, 2.0, 5.0
    rows = []
    for xi in (1e-9, 0.3, 1.0, 1.7):
        hx, hb = h_terms(xi, b, a, L)
        e = 1e-5
        if xi > 1e-6:
            fx = (
                np.log(premium(p, xi + e, b, a, L))
                - np.log(premium(p, xi - e, b, a, L))
            ) / (2 * e)
        else:
            fx = (
                np.log(premium(p, 2e-5, b, a, L))
                - np.log(premium(p, 0, b, a, L))
            ) / 2e-5
        fb = (
            np.log(premium(p, xi, b * np.exp(e), a, L))
            - np.log(premium(p, xi, b * np.exp(-e), a, L))
        ) / (2 * e)
        rows.append([xi, hx, fx, hb, fb])
    show(
        pd.DataFrame(
            rows,
            columns=[
                'xi',
                'h_xi',
                'finite_diff_xi',
                'h_beta',
                'finite_diff_beta',
            ],
        ),
        'CHECK  Appendix B derivatives against finite differences',
        'check_derivatives.csv',
        6,
    )

    # GPD fit against a brute-force search of the full likelihood on a fine
    # grid
    rng = np.random.default_rng(1)
    rows = []
    for xi0 in (-0.3, 0.2, 0.9, 1.5):
        U = rng.random(300)
        y = 2.0 * ((1 - U) ** (-xi0) - 1) / xi0
        x1, b1, f1 = gpd_fit(y[None, :])
        th = np.concatenate(
            [
                np.linspace(-1 / y.max() * 0.9999, -1e-9, 20000),
                np.geomspace(1e-9, 1e3, 40000),
            ]
        )
        lg = np.log1p(th[:, None] * y[None, :]).mean(1)
        ll = -np.log(lg / th) - lg - 1
        jb = np.nanargmax(np.where(np.isfinite(ll), ll, -np.inf))
        rows.append([xi0, x1[0], b1[0], lg[jb], lg[jb] / th[jb], f1[0]])
    show(
        pd.DataFrame(
            rows,
            columns=[
                'true_xi',
                'fit_xi',
                'fit_beta',
                'grid_xi',
                'grid_beta',
                'flag',
            ],
        ),
        'CHECK  GPD fit against a brute-force likelihood grid',
        'check_gpd_fit.csv',
        4,
    )


def _kappa_body(xi, qu, qR, m, ub):
    """kappa for an exactly GPD tail above u, with L = m R and u/beta = ub
    (beta = 1).
    """
    a = (((1 - qR) / (1 - qu)) ** (-xi) - 1) / xi
    return kappa(1 - qu, xi, 1.0, a, m * (ub + a))


def table3_body(cfg, quick, fresh):
    """Corollary 2 (Poisson counts) and Table 3 (kappa for different bodies via
    u/beta).
    """
    rows = []
    for qR in (0.95, 0.99):
        for xi in (0.2, 0.5, 0.9, 1.3, 2.0):
            for m in (0.5, 1, 2, 5, 10):
                k0 = lomax_kappa(xi, 0.8, qR, m)
                k1 = lomax_kappa(xi, 0.8, qR, m, poisson=True)
                rows.append([qR, k1 / k0, abs(k1 - np.sqrt(k0**2 + (1 - qR)))])
    pois = pd.DataFrame(rows, columns=['retention_q', 'ratio', 'err'])
    summ = (
        pois.groupby('retention_q')
        .agg(
            min_ratio=('ratio', 'min'),
            max_ratio=('ratio', 'max'),
            max_identity_error=('err', 'max'),
        )
        .reset_index()
    )
    show(
        summ,
        'COROLLARY 2  kappa_P / kappa (Poisson counts) and error in kappa_P^2'
        ' = kappa^2 + (1-qR)',
        'corollary2_poisson.csv',
        4,
    )

    rows = []
    for xi in (0.5, 0.9, 1.3):
        s = lomax_setup(xi, 0.8, 0.99, 2)
        ubl = s['u'] / s['beta']
        rows.append(
            [xi, ubl]
            + [
                _kappa_body(xi, 0.8, 0.99, m, ub)
                for m in (2, 5)
                for ub in (0.0, ubl, 2.0, 5.0)
            ]
        )
    tab3 = pd.DataFrame(
        rows,
        columns=[
            'xi',
            'u/beta_Lomax',
            'L=2R_u/b=0',
            'L=2R_Lomax',
            'L=2R_u/b=2',
            'L=2R_u/b=5',
            'L=5R_u/b=0',
            'L=5R_Lomax',
            'L=5R_u/b=2',
            'L=5R_u/b=5',
        ],
    )
    show(
        tab3,
        'TABLE 3  kappa for exactly GPD tails with different bodies '
        '(threshold 0.8, retention 0.99)',
        'table3_kappa_body.csv',
        2,
    )

    # Appendix C, Table C1: kappa for any exactly GPD tail, by the exceedance
    # ratio n_R/n_u,
    # the shape, and the limit relative to the GPD scale at the retention,
    # beta_R = beta + xi*a.
    rows = []
    for ratio in (0.25, 0.05):
        for xi in (0.2, 0.5, 0.9, 1.3, 2.0):
            a = (ratio ** (-xi) - 1) / xi  # retention a = R - u, with beta = 1
            beta_R = 1.0 + xi * a
            rows.append(
                [ratio, xi]
                + [
                    kappa(0.2, xi, 1.0, a, c * beta_R)
                    for c in (0.5, 1, 2, 5, 10)
                ]
            )
    tabC1 = pd.DataFrame(
        rows,
        columns=[
            'nR/nu',
            'xi',
            'L/bR=0.5',
            'L/bR=1',
            'L/bR=2',
            'L/bR=5',
            'L/bR=10',
        ],
    )
    show(
        tabC1,
        'TABLE C1  kappa for any exactly GPD tail (p = 0.2)',
        'tableC1_kappa_any_gpd.csv',
        2,
    )


def table10_real(cfg, quick, fresh):
    """Tables 10/15 (burning cost vs GPD on real data) and the data checks of
    Section 4.
    """
    rows = []
    for name, (R, L) in list(BENCH.items()) + list(EXTRA.items()):
        x = load(name)
        q = THRESHOLD_Q.get(name, 0.76)
        g = fitq(x, q, R, L)
        bc, bse = empirical_premium(x, R, L)
        nR = int((x > R).sum())
        rows.append(
            dict(
                dataset=name,
                n=len(x),
                obs_above_R=nR,
                gpd_q=q,
                xi_hat=g['xi'],
                gpd_premium=g['Pi'],
                burning_cost=bc,
                bc_over_gpd=bc / g['Pi'],
                gpd_rel_se=g['rse'],
                bc_rel_se=bse,
                kappa_gpd=g['rse'] * np.sqrt(nR),
                kappa_bc=bse * np.sqrt(nR),
            )
        )
    show(
        pd.DataFrame(rows),
        'TABLE 10  Real data: GPD premium vs burning cost',
        'table10_real_data.csv',
        4,
    )

    x = load('Norwegian 1988')
    say(
        '\nNorwegian 1988: the q = 0.92 threshold is %.1f, above the '
        'retention R = 5000,\n'
        'so Equation (1) does not apply there.' % np.quantile(x, 0.92)
    )

    grid = np.round(np.arange(0.60, 0.9201, 0.04), 2)
    idx = []
    for name in ('frecomfire', 'frebiloss'):
        d = read_r(name + '.rda')
        for c in ('ClaimCost', 'ClaimCost2007'):
            xx = d[c].to_numpy(float)
            xx = xx[np.isfinite(xx) & (xx > 0)]
            R = np.quantile(xx, 0.99)
            L = 2 * R
            fits = [fitq(xx, q, R, L) for q in grid]
            P = np.array([f['Pi'] for f in fits])
            idx.append(
                dict(
                    dataset=name,
                    amounts=c,
                    n=len(xx),
                    obs_above_R=int((xx > R).sum()),
                    mid_grid_rel_se=fits[4]['rse'],
                    xi_min=min(f['xi'] for f in fits),
                    xi_max=max(f['xi'] for f in fits),
                    grid_spread=(P.max() - P.min()) / np.median(P),
                )
            )
    show(
        pd.DataFrame(idx),
        'SECTION 4.3  Nominal vs indexed (2007) amounts',
        'section4_indexing.csv',
        3,
    )

    lf = read_r('lossalaefull.rda')
    above = lf['Loss'].to_numpy(float) > 475000
    say(
        '\nlossalae: %d losses above R = 475,000, of which %d are censored at'
        ' the policy limit'
        % (above.sum(), int(lf['Censored'].to_numpy()[above].sum()))
    )
    fm = read_r('fremarine.rda')
    say(
        'fremarine claim status (positive paid amounts): %s'
        % fm.loc[fm['ClaimPaid'] > 0, 'ClaimStatus'].value_counts().to_dict()
    )


def table12_subsampling(cfg, quick, fresh):
    """Table 12: known-truth subsampling from four large claim files, with the
    finite-population correction (FPC) and the burning cost."""
    reps = cfg['reps_sub']
    ck = Checkpoint('table12', quick, fresh)
    rows = ck.get('rows', [])
    done = ck.get('done', [])
    rng = _rng_from(ck.get('rng', SEED_SUB))
    for name in ('ausautoBI8999', 'freMTPL2sev', 'freMTPLsev', 'frecomfire'):
        pop = load(name)
        N = len(pop)
        for n in (500, 2000):
            if [name, n] in done:
                continue
            t0 = time.time()
            k = int(0.2 * n)
            S = np.array(
                [rng.choice(pop, n, replace=False) for _ in range(reps)]
            )
            Ss = np.sort(S, axis=1)
            u = Ss[:, n - k - 1]
            xi, be, fl = gpd_fit(Ss[:, n - k :] - u[:, None])
            del Ss
            fpc = np.sqrt(1 - n / N)
            for q in (0.90, 0.95, 0.99):
                R = np.quantile(pop, q)
                L = 2 * R
                pay = np.clip(pop - R, 0, L)
                Pi = pay.mean()
                P = np.array(
                    [
                        premium(k / n, xi[i], be[i], R - u[i], L)
                        for i in range(reps)
                    ]
                )
                se = np.array(
                    [
                        rel_se(k, k / n, xi[i], be[i], R - u[i], L)
                        for i in range(reps)
                    ]
                )
                bc = np.array(
                    [empirical_premium(S[i], R, L) for i in range(reps)]
                )
                lp = np.log(P)
                sdlog = lp.std(ddof=1)
                mse = np.median(se)
                rows.append(
                    dict(
                        data=name,
                        n=n,
                        qR=q,
                        nR=round(n * (1 - q)),
                        truth_rel_se=pay.std(ddof=1) / np.sqrt(N) / Pi,
                        gpd_bias=P.mean() / Pi - 1,
                        gpd_rmse=rmse(P / Pi - 1),
                        ratio=sdlog / mse,
                        ratio_fpc=sdlog / (mse * fpc),
                        cov=np.mean(np.abs(lp - np.log(Pi)) <= 1.645 * se),
                        cov_fpc=np.mean(
                            np.abs(lp - np.log(Pi)) <= 1.645 * se * fpc
                        ),
                        bc_bias=bc[:, 0].mean() / Pi - 1,
                        bc_rmse=rmse(bc[:, 0] / Pi - 1),
                        bc_cov_fpc=np.mean(
                            np.abs(bc[:, 0] - Pi)
                            <= 1.645 * bc[:, 1] * bc[:, 0] * fpc
                        ),
                        boundary_flags=int(fl.sum()),
                    )
                )
            del S
            gc.collect()
            done.append([name, n])
            ck.put('rows', rows)
            ck.put('done', done)
            ck.put('rng', rng.bit_generator.state)
            ck.save()
            say(
                '  %-14s n = %4d done (%.0f s) - saved'
                % (name, n, time.time() - t0)
            )
    t = pd.DataFrame(rows)
    show(
        t,
        'TABLE 12  Subsampling (ratio = SD of log premium / formula SE; cov ='
        ' 90% coverage)',
        'table12_subsampling.csv',
        3,
    )
    big = t.nR >= 20
    say('mean coverage with FPC: %.3f' % t.cov_fpc.mean())
    say(
        'designs with FPC ratio within 25%% of one: %d of %d'
        % (((t.ratio_fpc >= 0.8) & (t.ratio_fpc <= 1.25)).sum(), len(t))
    )
    say(
        'mean RMSE with n_R >= 20: GPD %.3f, burning cost %.3f'
        % (t[big].gpd_rmse.mean(), t[big].bc_rmse.mean())
    )


def _bc_block(d, n, reps, rng):
    """One (distribution, n) block of the GPD-vs-burning-cost simulation.
    Samples are
    generated in chunks (same random numbers as generating them all at once).
    """
    k = int(0.2 * n)
    QR = (0.95, 0.99, 0.998)
    Rs = [d.q(q) for q in QR]
    uq = d.q(0.8)
    lom = isinstance(d, Lomax)
    keys = ['gpd', 'se_full', 'bc', 'bc_relse'] + (
        ['logS_u', 'gpd_fixedu'] if lom else []
    )
    acc = {q: {kk: [] for kk in keys} for q in QR}
    flags = []
    for start in range(0, reps, SIM_CHUNK):
        c = min(SIM_CHUNK, reps - start)
        X = d.rvs(rng, (c, n))
        Xs = np.sort(X, axis=1)
        u = Xs[:, n - k - 1]
        xi, be, fl = gpd_fit(Xs[:, n - k :] - u[:, None])
        del Xs
        flags.append(fl)
        if lom:
            fx = [gpd_fit((X[i][X[i] > uq] - uq)[None, :]) for i in range(c)]
            nu2 = np.array([(X[i] > uq).sum() for i in range(c)])
            logS = np.log(np.array([_f(d.xi, u[i]) for i in range(c)]))
        for q, R in zip(QR, Rs):
            L = 2 * R
            A = acc[q]
            A['gpd'].append(
                np.array(
                    [
                        premium(k / n, xi[i], be[i], R - u[i], L)
                        for i in range(c)
                    ]
                )
            )
            V = np.array(
                [V_term(k / n, xi[i], be[i], R - u[i], L) for i in range(c)]
            )
            A['se_full'].append(np.sqrt(V / k))
            bc = np.array([empirical_premium(X[i], R, L) for i in range(c)])
            A['bc'].append(bc[:, 0])
            A['bc_relse'].append(bc[:, 1])
            if lom:
                A['logS_u'].append(logS)
                A['gpd_fixedu'].append(
                    np.array(
                        [
                            premium(
                                nu2[i] / n, fx[i][0][0], fx[i][1][0], R - uq, L
                            )
                            for i in range(c)
                        ]
                    )
                )
        del X
    flag = np.concatenate(flags)
    out = {}
    for q, R in zip(QR, Rs):
        L = 2 * R
        rec = {kk: np.concatenate(v) for kk, v in acc[q].items()}
        rec.update(
            flag=flag, Pi=true_premium(d, R, L), nR_exp=n * (1 - q), k=k, n=n
        )
        if lom:
            Vt = V_term(0.2, d.xi, 1 + d.xi * uq, R - uq, L)
            rec['se_true'] = np.sqrt(Vt / k)
            rec['se_true_nobin'] = np.sqrt((Vt - 0.8) / k)
        out[q] = rec
    return out


def table9_and_4(cfg, quick, fresh):
    """Tables 9/S5 (GPD vs burning cost, simulation) and Table 4 (variance
    decomposition).
    """
    reps = cfg['reps_bc']
    ck = Checkpoint('table9', quick, fresh)
    raw = ck.get('raw', {})  # (dist name, n) -> results of that block
    rng = _rng_from(ck.get('rng', SEED_BC))
    for d in (Lomax(0.5), Lomax(0.9), Lomax(1.2), Burr(0.9), LogNormal(1.5)):
        for n in (500, 2000):
            if (d.name, n) in raw:
                continue
            t0 = time.time()
            raw[(d.name, n)] = _bc_block(d, n, reps, rng)
            gc.collect()
            ck.put('raw', raw)
            ck.put('rng', rng.bit_generator.state)
            ck.save()
            say(
                '  %-20s n = %4d done (%.0f s) - saved'
                % (d.name, n, time.time() - t0)
            )

    mc = np.random.default_rng(0)  # Monte Carlo SE of the RMSE differences
    rows, decomp = [], []
    for (name, n), block in raw.items():
        for q, v in block.items():
            Pi = v['Pi']
            g = v['gpd'] / Pi - 1
            b = v['bc'] / Pi - 1
            lp = np.log(v['gpd'])
            idx = mc.integers(0, len(g), (400, len(g)))
            diff_se = (
                np.sqrt((g[idx] ** 2).mean(1)) - np.sqrt((b[idx] ** 2).mean(1))
            ).std()
            rows.append(
                dict(
                    dist=name,
                    n=n,
                    qR=q,
                    nR=round(v['nR_exp']),
                    gpd_bias=g.mean(),
                    gpd_rmse=rmse(g),
                    bc_rmse=rmse(b),
                    diff=rmse(g) - rmse(b),
                    diff_2mcse=2 * diff_se,
                    P_bc_zero=np.mean(v['bc'] == 0),
                    gpd_cov=np.mean(
                        np.abs(lp - np.log(Pi)) <= 1.645 * v['se_full']
                    ),
                    bc_cov=np.mean(
                        np.abs(v['bc'] - Pi) <= 1.645 * v['bc_relse'] * v['bc']
                    ),
                    boundary_flags=int(v['flag'].sum()),
                )
            )
            if 'se_true' in v and q in (0.95, 0.99):
                part = lp - np.log(v['k'] / n) + v['logS_u']
                decomp.append(
                    dict(
                        dist=name,
                        n=n,
                        qR=q,
                        nR=round(v['nR_exp']),
                        sim_sd=lp.std(ddof=1),
                        formula=v['se_true'],
                        formula_no_binomial=v['se_true_nobin'],
                        sim_sd_logS=v['logS_u'].std(ddof=1),
                        first_order_logS=np.sqrt(0.8 / v['k']),
                        sim_sd_gpd_part=part.std(ddof=1),
                        corr=np.corrcoef(part, -v['logS_u'])[0, 1],
                        sd_fixed_threshold=np.log(v['gpd_fixedu']).std(ddof=1),
                    )
                )
    show(
        pd.DataFrame(decomp),
        'TABLE 4  Variance decomposition (Lomax)',
        'table4_decomposition.csv',
        3,
    )
    show(
        pd.DataFrame(rows),
        'TABLES 9 / S5  GPD vs burning cost (bias and RMSE relative; cov = '
        '90%)',
        'table9_S5_gpd_vs_bc.csv',
        3,
    )


def table18_bootstrap(cfg, quick, fresh):
    """Table 18: formula interval vs percentile bootstrap vs burning cost.
    The slowest table (about 40 minutes with the paper's settings);
    progress is saved
    every BOOT_SAVE_EVERY replications."""
    reps, B = cfg['reps_boot'], cfg['B_boot']
    ck = Checkpoint('table18', quick, fresh)
    rows = ck.get('rows', [])
    finished = ck.get('finished', [])
    partial = ck.get('partial', {})
    for n, seed in ((300, SEED_BOOT_300), (1000, SEED_BOOT_1000)):
        rng = _rng_from(ck.get('rng_%d' % n, seed))
        k = int(round(0.24 * n))  # threshold at the sample 0.76 quantile
        for d in (Lomax(0.9), Lomax(1.1), Burr(0.9), LogNormal(1.5)):
            key = '%s|%d' % (d.name, n)
            if key in finished:
                continue
            R = d.q(0.99)
            L = 2 * R
            Pi = true_premium(d, R, L)
            rec = partial.get(key, [])
            t0 = time.time()
            while len(rec) < reps:
                x = d.rvs(rng, n)
                xs = np.sort(x)
                u = xs[n - k - 1]
                xi, be, fl = gpd_fit((xs[n - k :] - u)[None, :])
                xi, be = xi[0], be[0]
                P = premium(k / n, xi, be, R - u, L)
                se = rel_se(k, k / n, xi, be, R - u, L)
                bc, bcse = empirical_premium(x, R, L)
                Xb = np.sort(x[rng.integers(0, n, (B, n))], axis=1)
                ub = Xb[:, n - k - 1]
                xb, bb, fb = gpd_fit(Xb[:, n - k :] - ub[:, None])
                del Xb
                lo, hi = np.quantile(
                    premium_vec(k / n, xb, bb, R - ub, L), [0.05, 0.95]
                )
                rec.append(
                    [
                        P,
                        P * np.exp(-1.645 * se),
                        P * np.exp(1.645 * se),
                        lo,
                        hi,
                        bc,
                        bcse,
                        fl[0],
                        fb.mean(),
                    ]
                )
                if len(rec) % BOOT_SAVE_EVERY == 0 or len(rec) == reps:
                    partial[key] = rec
                    ck.put('partial', partial)
                    ck.put('rng_%d' % n, rng.bit_generator.state)
                    ck.save()
                    say(
                        '    %-20s n = %4d: %4d of %d replications (%.0f s) -'
                        ' saved'
                        % (d.name, n, len(rec), reps, time.time() - t0)
                    )
            r = np.array(rec)
            P, flo, fhi, blo, bhi, bc, bcse = (r[:, j] for j in range(7))
            with np.errstate(divide='ignore'):
                bw = np.median(np.log(bhi / blo))
            rows.append(
                dict(
                    dist=d.name,
                    n=n,
                    formula_cov=np.mean((flo <= Pi) & (Pi <= fhi)),
                    boot_cov=np.mean((blo <= Pi) & (Pi <= bhi)),
                    formula_logwidth=np.median(np.log(fhi / flo)),
                    boot_logwidth=bw,
                    truth_below_boot=np.mean(Pi < blo),
                    truth_above_boot=np.mean(Pi > bhi),
                    bc_cov=np.mean(np.abs(bc - Pi) <= 1.645 * bcse * bc),
                    gpd_rmse=rmse(P / Pi - 1),
                    bc_rmse=rmse(bc / Pi - 1),
                    boundary_flags=int(r[:, 7].sum()),
                    boot_boundary_rate=r[:, 8].mean(),
                )
            )
            finished.append(key)
            partial.pop(key, None)
            ck.put('rows', rows)
            ck.put('finished', finished)
            ck.put('partial', partial)
            ck.put('rng_%d' % n, rng.bit_generator.state)
            ck.save()
            gc.collect()
    show(
        pd.DataFrame(rows),
        'TABLE 18  Coverage of nominal 90% intervals (RMSE relative)',
        'table18_bootstrap.csv',
        3,
    )


# =============================================================================
# 6b. BENCHMARK LAYERS AND THRESHOLD STABILITY (Tables 11, 14, 15, 16, 19)
# =============================================================================
# Threshold grids (quantiles) for the averaging results.
GRID_Q = {
    'Secura': [0.30, 0.35, 0.40, 0.45, 0.50],
    'Danish': [round(0.80 + 0.01 * i, 2) for i in range(16)],
    'Norwegian 1988': [round(0.70 + 0.02 * i, 2) for i in range(11)],
}
GRID_EXTRA = [round(0.60 + 0.04 * i, 2) for i in range(9)]

def fit_at_u(x, u, R, L):
    """GPD fit above threshold u; premium, BIC and S_j at that threshold."""
    n = len(x)
    y = x[x > u] - u
    k = len(y)
    xi, b, fl = gpd_fit(y[None, :])
    xi, b, p = xi[0], b[0], k / n
    ll = -k * np.log(b) - (1.0 / xi + 1.0) * np.log1p(xi * y / b).sum()
    ll += k * np.log(p) + (n - k) * np.log(1.0 - p)
    hx, hb = h_terms(xi, b, R - u, L)
    return dict(
        u=u,
        k=k,
        xi=xi,
        beta=b,
        Pi=premium(p, xi, b, R - u, L),
        rse=rel_se(k, p, xi, b, R - u, L),
        bic=-2.0 * ll + 3.0 * np.log(n),
        S=abs(hx) * (1.0 + xi) / np.sqrt(k),
        flag=int(fl[0]),
    )


def grid_fit(x, qs, R, L):
    """Fits on a quantile grid; repeated thresholds (ties) are dropped."""
    out, seen = [], set()
    for q in qs:
        u = float(np.quantile(x, q))
        if u in seen or u >= R:
            continue
        seen.add(u)
        f = fit_at_u(x, u, R, L)
        f['q'] = q
        out.append(f)
    return out


def naive_bma(fits):
    """BIC weights exp(-BIC/2) across thresholds (Section 3)."""
    b = np.array([f['bic'] for f in fits])
    w = np.exp(-(b - b.min()) / 2.0)
    w /= w.sum()
    return float(np.sum(w * np.array([f['Pi'] for f in fits]))), w


def spread(P):
    P = np.asarray(P)
    return (P.max() - P.min()) / np.median(P)


def table14_16_benchmarks(cfg, quick, fresh):
    """Tables 14, 15 and 16: premiums at the benchmark layers."""
    t14, t15, t16 = [], [], []
    for name, (R, L) in BENCH.items():
        x = load(name)
        n = len(x)
        fits = grid_fit(x, GRID_Q[name], R, L)
        P = np.array([f['Pi'] for f in fits])
        xis = np.array([f['xi'] for f in fits])
        t14.append(
            dict(
                dataset=name,
                q_from=fits[0]['q'],
                q_to=fits[-1]['q'],
                thresholds=len(fits),
                xi_min=xis.min(),
                xi_max=xis.max(),
                Pi_min=P.min(),
                Pi_max=P.max(),
                spread_pct=100 * spread(P),
            )
        )
        single = fit_at_u(x, float(np.quantile(x, THRESHOLD_Q[name])), R, L)
        bma, w = naive_bma(fits)
        bc, _ = empirical_premium(x, R, L)
        t15.append(
            dict(
                dataset=name,
                single_mid_grid=single['Pi'],
                naive_bma=bma,
                bma_weight_top=w[-1],
                equal_weight=P.mean(),
                burning_cost=bc,
            )
        )
        xs = np.sort(x)
        rules = [('Single (mid-grid)', single)]
        for lab, fn in (('Hill plateau', hill_plateau_k),
                        ('MRL linear', mrl_linear_k)):
            k = fn(xs)
            rules.append((lab, fit_at_u(x, float(xs[n - k - 1]), R, L)))
        for lab, f in rules:
            t16.append(
                dict(
                    dataset=name,
                    method=lab,
                    u_star=f['u'],
                    n_j=f['k'],
                    xi_hat=f['xi'],
                    Pi_hat=f['Pi'],
                    ES_multiplier=1.0 / (1.0 - f['xi']),
                    vs_naive_bma_pct=100 * (f['Pi'] / bma - 1),
                    vs_equal_weight_pct=100 * (f['Pi'] / P.mean() - 1),
                )
            )
    show(pd.DataFrame(t14), 'TABLE 14  Premium across the threshold grid',
         'table14_grid_stability.csv', 4)
    show(pd.DataFrame(t15), 'TABLE 15  Premium by method',
         'table15_methods.csv', 4)
    show(pd.DataFrame(t16), 'TABLE 16  Classical threshold rules',
         'table16_rules.csv', 4)


def table11_19_real(cfg, quick, fresh):
    """Tables 11 and 19: formula vs bootstrap standard errors on the real
    data (threshold re-set at the sample quantile in every resample) and
    threshold stability in the additional datasets."""
    B = cfg['B_real']
    rng = np.random.default_rng(SEED_REAL)
    t11, t19, grid_rows = [], [], []
    for name, (R, L) in list(BENCH.items()) + list(EXTRA.items()):
        x = load(name)
        n = len(x)
        nR = int((x > R).sum())
        fits = grid_fit(x, GRID_Q.get(name, GRID_EXTRA), R, L)
        boot, form = [], []
        for f in fits:
            Xb = np.sort(x[rng.integers(0, n, (B, n))], axis=1)
            ub = np.quantile(Xb, f['q'], axis=1)
            Pb = np.empty(B)
            for i in range(B):
                yb = Xb[i][Xb[i] > ub[i]] - ub[i]
                a, bb, _ = gpd_fit(yb[None, :])
                Pb[i] = premium(len(yb) / n, a[0], bb[0], R - ub[i], L)
            del Xb
            boot.append(np.std(Pb, ddof=1) / f['Pi'])
            form.append(f['rse'])
            lo, hi = np.quantile(Pb, [0.05, 0.95])
            grid_rows.append(
                dict(
                    dataset=name,
                    q=f['q'],
                    u=f['u'],
                    k=f['k'],
                    xi=f['xi'],
                    Pi=f['Pi'],
                    formula_rel_se=f['rse'],
                    boot_se=np.std(Pb, ddof=1),
                    boot_q05=lo,
                    boot_q95=hi,
                    S=f['S'],
                )
            )
        bma, _ = naive_bma(fits)
        for r in grid_rows[-len(fits):]:
            r['naive_bma'] = bma
            r['equal_weight'] = np.mean([f['Pi'] for f in fits])
        boot, form = np.array(boot), np.array(form)
        ratio = boot / form
        t11.append(
            dict(
                dataset=name,
                n=n,
                obs_above_R=nR,
                thresholds=len(fits),
                boot_rel_se_pct=100 * np.median(boot),
                formula_rel_se_pct=100 * np.median(form),
                ratio_median=np.median(ratio),
                ratio_min=ratio.min(),
                ratio_max=ratio.max(),
                boot_se_x_sqrt_nR=np.median(boot) * np.sqrt(nR),
            )
        )
        if name in EXTRA:
            xis = [f['xi'] for f in fits]
            t19.append(
                dict(
                    dataset=name,
                    n=n,
                    thresholds=len(fits),
                    xi_min=min(xis),
                    xi_max=max(xis),
                    xi_lowest_q=xis[0],
                    xi_highest_q=xis[-1],
                    spread_pct=100 * spread([f['Pi'] for f in fits]),
                    median_boot_se_pct=100 * np.median(boot),
                    max_S=max(f['S'] for f in fits),
                )
            )
        say('    %-15s done' % name)
    show(pd.DataFrame(t11), 'TABLE 11  Formula vs bootstrap SE (B = %d)' % B,
         'table11_formula_vs_bootstrap.csv', 3)
    show(pd.DataFrame(t19), 'TABLE 19  Threshold stability, additional data',
         'table19_threshold_stability.csv', 3)
    x = load('freMTPLsev')
    R, L = EXTRA['freMTPLsev']
    qs = [round(0.80 + 0.02 * i, 2) for i in range(7)]
    f = grid_fit(x, qs, R, L)
    say(
        '\nfreMTPLsev, grid restricted to q = 0.80, 0.82, ..., 0.92: '
        'spread %.1f%%' % (100 * spread([g['Pi'] for g in f]))
    )
    # Per-threshold results, used by make_paper_figures_4_5.py.
    pd.DataFrame(grid_rows).to_csv(
        os.path.join(OUT_DIR, 'real_grid_bootstrap.csv'), index=False
    )


# =============================================================================
# 6c. FURTHER TABLES (1, 5-8, 13, 16 rules, 17, S1-S4) AND FIGURE DATA
# =============================================================================
# Seeds for the steps of this section.
SEED_LOMAX = 20261201  # Table 7 and Figure 2
SEED_BEYOND = 20261202  # Table 8 and Figure 3 (simulations)
SEED_EXPA = 20261203  # Table 13 and Figure 3 (real-data subsamples)
SEED_AVG = 20261204  # Table 17, Table S2 and TPW in simulation
SEED_TPW_REAL = 20261205  # Tables S1 and S3, Figure S1
SEED_TRIM = 20261206  # Table S4

# Averaging grid of the simulations (Section 5).
GRID_SIM = [round(0.60 + 0.04 * i, 2) for i in range(9)]


class SplicedMixture:
    """Section 6.2 mixture: a lognormal body (sigma 1.5) below the split
    point 3 with probability 0.95, and a Pareto tail with xi = 0.9 above it:
    S(x) = 0.05 (x / 3)^(-1 / 0.9) for x > 3."""

    def __init__(self, sigma=1.5, xi=0.9, split=3.0, w_tail=0.05):
        self.s, self.xi, self.c, self.w = sigma, xi, split, w_tail
        self.Fb = 1.0 - 0.5 * math.erfc(math.log(split) / (sigma * 2**0.5))
        self.name = 'Mixture'

    def sf(self, x):
        x = np.asarray(x, float)
        with np.errstate(divide='ignore', invalid='ignore'):
            Phi = 1.0 - 0.5 * _erfc(
                np.log(np.maximum(x, 1e-300)) / (self.s * 2**0.5)
            ).astype(float)
            body = 1.0 - (1.0 - self.w) * Phi / self.Fb
            tail = self.w * (x / self.c) ** (-1.0 / self.xi)
        return np.where(x > self.c, tail, body)

    def q(self, p):
        if p <= 1.0 - self.w:
            return math.exp(self.s * _N01.inv_cdf(p / (1 - self.w) * self.Fb))
        return self.c * ((1.0 - p) / self.w) ** (-self.xi)

    def rvs(self, rng, size):
        size = (size,) if np.isscalar(size) else tuple(size)
        m = int(np.prod(size))
        tail = rng.random(m) < self.w
        out = np.empty(m)
        nt = int(tail.sum())
        out[tail] = self.c * rng.random(nt) ** (-self.xi)
        body = []
        need = m - nt
        while need > 0:  # lognormal draws conditioned on x <= split
            z = np.exp(self.s * rng.standard_normal(int(need / 0.7) + 10))
            z = z[z <= self.c][:need]
            body.append(z)
            need -= len(z)
        out[~tail] = np.concatenate(body) if body else []
        return out.reshape(size)


# ---- threshold-selection rules ---------------------------------------------
def rule_candidates(n):
    """Candidate numbers of exceedances for the Hill and MRL rules: 60
    values spaced evenly on the log scale from max(15, 2% of n) to n / 2."""
    kmin = max(15, int(np.ceil(0.02 * n)))
    kmax = max(kmin + 6, int(0.5 * n))
    return np.unique(np.round(np.geomspace(kmin, kmax, 60)).astype(int))


def hill_plateau_k(xs):
    """Hill-plateau rule. xs: sorted positive sample. The Hill estimate
    H_k = mean(log of the k largest) - log X_(n-k) is computed at each
    candidate k; among all windows of six consecutive candidates, the one
    with the smallest coefficient of variation of H_k is the plateau, and
    the rule returns its third candidate (the centre of the window)."""
    n = len(xs)
    K = rule_candidates(n)
    lx = np.log(xs)
    top = np.cumsum(lx[::-1])
    H = top[K - 1] / K - lx[n - K - 1]
    best, bi = np.inf, 0
    for i in range(len(K) - 5):
        h = H[i : i + 6]
        cv = h.std(ddof=1) / abs(h.mean())
        if cv < best:
            best, bi = cv, i
    return int(K[bi + 2])


def mrl_linear_k(xs):
    """MRL-linear rule: the automated mean-residual-life rule of Langousis
    et al. (2016, Section 2.2), as in the R function mev::automrl. xs:
    sorted sample. The mean excess e_j over u_j = X_(n-j) is computed for
    j = 10, ..., n / 2 exceedances, with weight j / s_j^2 (s_j^2 = sample
    variance of the j exceedances). For each candidate k, a weighted least-
    squares line of e_j on u_j is fitted to the points with j < k (thresholds
    above u_k); the rule returns the candidate with the smallest weighted
    mean squared residual."""
    n = len(xs)
    K = rule_candidates(n)
    jmax = int(K.max())
    top = xs[::-1][: jmax + 1] / xs[-1]  # scaled to avoid round-off
    j = np.arange(10, jmax + 1)
    c1, c2 = np.cumsum(top), np.cumsum(top**2)
    m = c1[j - 1] / j
    var = np.maximum((c2[j - 1] / j - m**2) * j / (j - 1), 1e-300)
    u = top[j]  # X_(n-j), scaled
    e = m - u
    w = j / var
    best, chosen = np.inf, int(K[0])
    for k in K:
        s = j < k
        if s.sum() < 3:
            continue
        uu, ee, ww = u[s], e[s], w[s]
        W = ww.sum()
        ub, eb = (ww * uu).sum() / W, (ww * ee).sum() / W
        sxx = (ww * (uu - ub) ** 2).sum()
        b = (ww * (uu - ub) * (ee - eb)).sum() / sxx if sxx > 0 else 0.0
        mse = (ww * (ee - eb - b * (uu - ub)) ** 2).sum() / W
        if mse < best:
            best, chosen = mse, int(k)
    return chosen


# ---- fits on a grid of order-statistic thresholds (simulations) -----------
def _ks(n, qs):
    """Number of exceedances at the sample q-quantile thresholds."""
    return [int(round((1.0 - q) * n)) for q in qs]


def fit_grid_rows(Xs, ks):
    """GPD fits for each row of the sorted sample matrix Xs at the thresholds
    u = X_(n-k), k in ks. Returns arrays of shape (rows, len(ks))."""
    r, n = Xs.shape
    J = len(ks)
    out = {v: np.empty((r, J)) for v in ('xi', 'be', 'u', 'll')}
    for j, k in enumerate(ks):
        u = Xs[:, n - k - 1]
        Y = Xs[:, n - k :] - u[:, None]
        xi, be, _ = gpd_fit(Y)
        with np.errstate(divide='ignore', invalid='ignore'):
            z = np.log1p(xi[:, None] * Y / be[:, None]).sum(1)
            ll = np.where(
                np.abs(xi) > 1e-8,
                -k * np.log(be) - (1.0 / xi + 1.0) * z,
                -k * np.log(be) - Y.sum(1) / be,
            )
        p = k / n
        out['xi'][:, j], out['be'][:, j], out['u'][:, j] = xi, be, u
        out['ll'][:, j] = ll + k * np.log(p) + (n - k) * np.log(1 - p)
    out['ks'], out['n'] = list(ks), n
    return out


def premium_general(x, k, n, xi, be, u, R, L):
    """Layer premium from a GPD fitted above u. If u lies above the
    retention, the part of the layer below u uses the empirical survival
    function of the sample x."""
    if u <= R:
        return premium(k / n, xi, be, R - u, L)
    low = np.mean(np.clip(x - R, 0.0, min(u, R + L) - R))
    if u >= R + L:
        return low
    return low + premium(k / n, xi, be, 0.0, R + L - u)


def grid_premiums(G, Xs, R, L):
    """Premiums (rows, J) at each grid threshold for the layer (R, L)."""
    xi, be, u = G['xi'], G['be'], G['u']
    r, J = xi.shape
    n = G['n']
    P = np.empty((r, J))
    for j, k in enumerate(G['ks']):
        P[:, j] = premium_vec(
            k / n, xi[:, j], be[:, j], np.maximum(R - u[:, j], 0.0), L
        )
        for i in np.where(u[:, j] > R)[0]:
            P[i, j] = premium_general(
                Xs[i], k, n, xi[i, j], be[i, j], u[i, j], R, L
            )
    return P


def bma_weights(LL):
    """Naive BMA weights from log-likelihoods (rows, J); BIC = -2 ll + const.
    """
    w = np.exp(LL - LL.max(1, keepdims=True))
    return w / w.sum(1, keepdims=True)


def stability_index(XI):
    """Parameter-stability rule (Section 3.6): the lowest grid threshold at
    which xi-hat varies by at most 0.2 over it and the next two; otherwise
    the lowest threshold of the highest such window."""
    r, J = XI.shape
    idx = np.full(r, J - 3)
    for i in range(r):
        for j in range(J - 2):
            w = XI[i, j : j + 3]
            if w.max() - w.min() <= 0.2:
                idx[i] = j
                break
    return idx


def tpw(P, Pb):
    """Target-specific precision weighting (Supplement, Equation S1).
    P: premiums (J,); Pb: bootstrap premiums (B, J), the same resamples at
    every threshold. Returns the TPW premium, its weights and rho."""
    s2 = np.maximum(Pb.var(0, ddof=1), 1e-300)
    w0 = (1.0 / s2) / (1.0 / s2).sum()
    th = (w0 * P).sum()
    thb = Pb @ w0
    v = (Pb - thb[:, None]).var(0, ddof=1)
    tau2 = np.maximum((P - th) ** 2 - v, 0.0)
    w = 1.0 / (s2 + tau2)
    w /= w.sum()
    return float((w * P).sum()), w, float(np.sqrt(tau2 / s2).max())


def tpw_trimmed(P, Pb):
    """TPW after trimming the lowest thresholds until rho <= 1 (at least
    three thresholds are kept)."""
    j0 = 0
    est, w, rho = tpw(P, Pb)
    while rho > 1.0 and len(P) - j0 > 3:
        j0 += 1
        est, w, rho = tpw(P[j0:], Pb[:, j0:])
    return est


def entropy(w):
    w = np.asarray(w, float)
    w = w[w > 0]
    return float(-(w * np.log(w)).sum())


# ---- Tables 1, 5 and 6 -----------------------------------------------------
def table1_data(cfg, quick, fresh):
    """Table 1 (n_R = (kappa / target)^2) and the computed columns of
    Tables 5 and 6 (sample sizes; layers at the 0.99 quantile, L = 2R)."""
    rows = [
        dict(target=t, **{'kappa=%.1f' % k: (k / t) ** 2
                          for k in (0.8, 1.1, 1.8)})
        for t in (0.10, 0.20, 0.30)
    ]
    show(pd.DataFrame(rows), 'TABLE 1  n_R = (kappa / target)^2',
         'table1_nR.csv', 1)
    rows = []
    for name in list(BENCH) + list(EXTRA) + ['lossalae']:
        x = load(name)
        R = float(np.quantile(x, 0.99))
        rows.append(dict(dataset=name, n=len(x), q99=R, L_2R=2 * R,
                         layer_used=str(BENCH.get(name, EXTRA.get(name)))))
    show(pd.DataFrame(rows), 'TABLES 5 and 6  Sample sizes and 0.99 '
         'quantiles (layers used in the paper in the last column)',
         'table5_6_data.csv', 1)


# ---- Table 7 and Figure 2 --------------------------------------------------
def table7_lomax(cfg, quick, fresh):
    """Table 7: formula against simulated relative RMSE, Lomax losses,
    threshold at the sample 0.8 quantile, L = 2R."""
    reps = cfg['reps_lomax']
    rng = np.random.default_rng(SEED_LOMAX)
    rows = []
    for xi in (0.5, 0.9, 1.2):
        d = Lomax(xi)
        for n in (500, 2000, 8000):
            k = int(0.2 * n)
            Rs = {q: d.q(q) for q in (0.95, 0.99)}
            P = {q: [] for q in Rs}
            for start in range(0, reps, SIM_CHUNK):
                c = min(SIM_CHUNK, reps - start)
                Xs = np.sort(d.rvs(rng, (c, n)), axis=1)
                u = Xs[:, n - k - 1]
                xh, bh, _ = gpd_fit(Xs[:, n - k :] - u[:, None])
                for q, R in Rs.items():
                    P[q].append(premium_vec(k / n, xh, bh, R - u, 2 * R))
                del Xs
            for q, R in Rs.items():
                Pi = true_premium(d, R, 2 * R)
                p = np.concatenate(P[q])
                nR = n * (1 - q)
                form = lomax_kappa(xi, 0.8, q, 2) / np.sqrt(nR)
                rows.append(dict(
                    xi=xi, n=n, qR=q, nR=nR, formula_pct=100 * form,
                    sim_rmse_pct=100 * rmse(p / Pi - 1),
                    sim_bias_pct=100 * (p.mean() / Pi - 1),
                    sd_log=np.log(p).std(ddof=1), formula_log=form))
            say('    Lomax xi=%.1f n=%d done' % (xi, n))
    show(pd.DataFrame(rows), 'TABLE 7  Formula vs simulated relative RMSE '
         '(Lomax; also the data of Figure 2)', 'table7_lomax.csv', 3)


# ---- Table 8 and Figure 3 (simulation part) -------------------------------
def table8_beyond(cfg, quick, fresh):
    """Table 8 and the 216 design-level results of Section 6.2 (Figure 3):
    thresholds at the sample 0.6, 0.8 and 0.9 quantiles, nine layers."""
    reps = cfg['reps_beyond']
    ck = Checkpoint('table8', quick, fresh)
    rows = ck.get('rows', [])
    done = ck.get('done', [])
    rng = _rng_from(ck.get('rng', SEED_BEYOND))
    dists = [Lomax(0.9), Burr(0.9), LogNormal(1.5), SplicedMixture()]
    layers = [(qR, m) for qR in (0.90, 0.95, 0.99) for m in (0.5, 2, 5)]
    for d in dists:
        for n in (500, 2000):
            key = '%s|%d' % (d.name, n)
            if key in done:
                continue
            X = d.rvs(rng, (reps, n))
            Xs = np.sort(X, axis=1)
            G = fit_grid_rows(Xs, _ks(n, (0.6, 0.8, 0.9)))
            for qR, m in layers:
                R = d.q(qR)
                L = m * R
                Pi = true_premium(d, R, L)
                P = grid_premiums(G, Xs, R, L)
                for j, qu in enumerate((0.6, 0.8, 0.9)):
                    k = G['ks'][j]
                    se = np.array([
                        rel_se(k, k / n, G['xi'][i, j], G['be'][i, j],
                               max(R - G['u'][i, j], 0.0), L)
                        for i in range(reps)])
                    lp = np.log(P[:, j])
                    sdl = lp.std(ddof=1)
                    nR = n * (1 - qR)
                    rows.append(dict(
                        dist=d.name, n=n, qu=qu, qR=qR, L_over_R=m, nR=nR,
                        ratio=sdl / np.median(se),
                        cov=np.mean(np.abs(lp - np.log(Pi)) <= 1.645 * se),
                        emp_kappa=sdl * np.sqrt(nR),
                        bias_pct=100 * (P[:, j].mean() / Pi - 1),
                        sd_log=sdl, med_se=np.median(se)))
            del X, Xs
            done.append(key)
            ck.put('rows', rows)
            ck.put('done', done)
            ck.put('rng', rng.bit_generator.state)
            ck.save()
            say('    %-20s n = %4d done - saved' % (d.name, n))
    t = pd.DataFrame(rows)
    t.to_csv(os.path.join(OUT_DIR, 'table8_all_settings.csv'), index=False)
    s = []
    for (dn, n), g in t[t.qu == 0.8].groupby(['dist', 'n']):
        s.append(dict(
            dist=dn, n=n, nR='%g-%g' % (g.nR.min(), g.nR.max()),
            ratio_med=g.ratio.median(), ratio_min=g.ratio.min(),
            ratio_max=g.ratio.max(), cov_med=g['cov'].median(),
            cov_min=g['cov'].min(), cov_max=g['cov'].max(),
            emp_kappa_min=g.emp_kappa.min(), emp_kappa_max=g.emp_kappa.max(),
            bias_min=g.bias_pct.min(), bias_max=g.bias_pct.max()))
    show(pd.DataFrame(s), 'TABLE 8  Formula vs simulation, threshold 0.8',
         'table8_beyond_lomax.csv', 3)
    sm = t[t.dist != 'Mixture']
    mx = t[t.dist == 'Mixture']
    say('162 settings (Lomax, Burr, lognormal): ratio median %.2f, range '
        '%.2f-%.2f; ratio > 1.15 in %d settings (%d with n_R = 5)'
        % (sm.ratio.median(), sm.ratio.min(), sm.ratio.max(),
           (sm.ratio > 1.15).sum(),
           ((sm.ratio > 1.15) & np.isclose(sm.nR, 5)).sum()))
    say('coverage: all %.2f-%.2f; threshold 0.8 %.2f-%.2f'
        % (sm['cov'].min(), sm['cov'].max(), sm[sm.qu == 0.8]['cov'].min(),
           sm[sm.qu == 0.8]['cov'].max()))
    m8 = mx[mx.qu == 0.8]
    say('mixture at 0.8: ratio %.2f-%.2f, bias %.1f%% to %.1f%%, coverage '
        '%.2f-%.2f; coverage at 0.6: min %.2f'
        % (m8.ratio.min(), m8.ratio.max(), m8.bias_pct.min(),
           m8.bias_pct.max(), m8['cov'].min(), m8['cov'].max(),
           mx[mx.qu == 0.6]['cov'].min()))


# ---- Table 13 and Figure 3 (Experiment A) ---------------------------------
def _quantile_fits(x, qs):
    """GPD fits above the sample q-quantiles of x (strict exceedances, as for
    the real data); quantiles that give the same threshold share one fit."""
    n = len(x)
    out, cache = {}, {}
    for q in qs:
        u = float(np.quantile(x, q))
        if u not in cache:
            y = x[x > u] - u
            k = len(y)
            a, b, _ = gpd_fit(y[None, :])
            a, b = a[0], b[0]
            ll = -k * np.log(b) - (1 / a + 1) * np.log1p(a * y / b).sum()
            ll += k * np.log(k / n) + (n - k) * np.log(1 - k / n)
            cache[u] = dict(u=u, k=k, xi=a, be=b, ll=ll)
        out[q] = cache[u]
    return out


def _prem(x, g, R, L):
    return premium_general(x, g['k'], len(x), g['xi'], g['be'], g['u'], R,
                           L)


def table13_expA(cfg, quick, fresh):
    """Table 13 (Experiment A): subsamples without replacement from four
    large files; single mid-grid, naive BMA, equal-weight and stability
    rules against the population premium."""
    reps = cfg['reps_expA']
    rng = np.random.default_rng(SEED_EXPA)
    grids = {
        0.90: [round(0.50 + 0.04 * i, 2) for i in range(10)],
        0.95: [round(0.60 + 0.04 * i, 2) for i in range(8)],
        0.99: [round(0.60 + 0.04 * i, 2) for i in range(9)],
    }
    union = sorted(set(q for g in grids.values() for q in g))
    rows = []
    for name in ('ausautoBI8999', 'freMTPL2sev', 'freMTPLsev', 'frecomfire'):
        pop = load(name)
        for n in (500, 2000):
            S = [rng.choice(pop, n, replace=False) for _ in range(reps)]
            F = [_quantile_fits(x, union) for x in S]
            for qR, grid in grids.items():
                R = float(np.quantile(pop, qR))
                L = 2 * R
                Pi = np.clip(pop - R, 0, L).mean()
                mid = len(grid) // 2
                est = {r: np.empty(reps) for r in
                       ('single', 'naive', 'equal', 'stability')}
                se = np.empty(reps)
                Pm = np.empty(reps)
                for i, x in enumerate(S):
                    f = [F[i][q] for q in grid]
                    uniq = list({id(g): g for g in f}.values())
                    P = np.array([_prem(x, g, R, L) for g in uniq])
                    ll = np.array([g['ll'] for g in uniq])
                    w = np.exp(ll - ll.max())
                    w /= w.sum()
                    st = stability_index(
                        np.array([[g['xi'] for g in uniq]]))[0]
                    g = f[mid]
                    Pm[i] = _prem(x, g, R, L)
                    est['single'][i] = Pm[i]
                    est['naive'][i] = (w * P).sum()
                    est['equal'][i] = P.mean()
                    est['stability'][i] = P[st]
                    se[i] = rel_se(g['k'], g['k'] / n, g['xi'], g['be'],
                                   max(R - g['u'], 0.0), L)
                lp = np.log(Pm)
                rows.append(dict(
                    data=name, n=n, qR=qR, q_mid=grid[mid],
                    **{'rmse_' + r: 100 * rmse(e / Pi - 1)
                       for r, e in est.items()},
                    sd_log=lp.std(ddof=1), med_se=np.median(se),
                    cov=np.mean(np.abs(lp - np.log(Pi)) <= 1.645 * se)))
            say('    %-14s n = %4d done' % (name, n))
    t = pd.DataFrame(rows)
    t.to_csv(os.path.join(OUT_DIR, 'table13_designs.csv'), index=False)
    c = ['rmse_single', 'rmse_naive', 'rmse_equal', 'rmse_stability']
    s = pd.concat([
        t.groupby('data')[c].mean(),
        t.groupby('qR')[c].mean().rename(index=lambda q: 'retention %.2f'
                                         % q),
        t[c].mean().to_frame('All 24 designs').T])
    show(s.reset_index(), 'TABLE 13  Experiment A: relative RMSE (%)',
         'table13_expA.csv', 1)


# ---- Table 17, Table S2 and TPW in the Monte Carlo study ------------------
def table17_averaging(cfg, quick, fresh):
    """Table 17 (relative RMSE of six rules), the paired differences from the
    single threshold, TPW (Supplement S3) and Table S2 (percentile bootstrap
    with B resamples and the weights held fixed)."""
    reps, B = cfg['reps_avg'], cfg['B_avg']
    ck = Checkpoint('table17', quick, fresh)
    res = ck.get('res', {})
    rng = _rng_from(ck.get('rng', SEED_AVG))
    rules = ['single', 'naive', 'equal', 'stability', 'hill', 'mrl', 'tpw']
    dists = [Lomax(0.9), Lomax(1.1), Burr(0.9), LogNormal(1.5)]
    for d in dists:
        for n in (300, 1000):
            key = '%s|%d' % (d.name, n)
            if key in res and res[key]['m'] >= reps:
                continue
            rec = res.get(key, dict(m=0, est={r: [] for r in rules},
                                    lo={}, hi={}, maxw=[]))
            for r in ('single', 'naive', 'equal', 'tpw'):
                rec['lo'].setdefault(r, [])
                rec['hi'].setdefault(r, [])
            R = d.q(0.99)
            L = 2 * R
            ks = _ks(n, GRID_SIM)
            mid = len(GRID_SIM) // 2
            t0 = time.time()
            while rec['m'] < reps:
                x = d.rvs(rng, n)
                xs = np.sort(x)[None, :]
                G = fit_grid_rows(xs, ks)
                P = grid_premiums(G, xs, R, L)[0]
                w = bma_weights(G['ll'])[0]
                st = stability_index(G['xi'])[0]
                Xb = np.sort(x[rng.integers(0, n, (B, n))], axis=1)
                Gb = fit_grid_rows(Xb, ks)
                Pb = grid_premiums(Gb, Xb, R, L)
                del Xb
                e_tpw, w_tpw, _ = tpw(P, Pb)
                e = dict(single=P[mid], naive=(w * P).sum(),
                         equal=P.mean(), stability=P[st], tpw=e_tpw)
                for lab, fn in (('hill', hill_plateau_k),
                                ('mrl', mrl_linear_k)):
                    k = fn(xs[0])
                    u = xs[0, n - k - 1]
                    a, b, _ = gpd_fit((xs[0, n - k :] - u)[None, :])
                    e[lab] = premium_general(x, k, n, a[0], b[0], u, R, L)
                for r in rules:
                    rec['est'][r].append(float(e[r]))
                bs = dict(single=Pb[:, mid], naive=Pb @ w,
                          equal=Pb.mean(1), tpw=Pb @ w_tpw)
                for r, v in bs.items():
                    lo, hi = np.quantile(v, [0.05, 0.95])
                    rec['lo'][r].append(float(lo))
                    rec['hi'][r].append(float(hi))
                rec['maxw'].append(float(w.max()))
                rec['m'] += 1
                if rec['m'] % 50 == 0 or rec['m'] == reps:
                    res[key] = rec
                    ck.put('res', res)
                    ck.put('rng', rng.bit_generator.state)
                    ck.save()
                    say('    %-20s n = %4d: %4d of %d (%.0f s) - saved'
                        % (d.name, n, rec['m'], reps, time.time() - t0))
    rows, diffs, s2 = [], [], []
    for d in dists:
        for n in (300, 1000):
            rec = res['%s|%d' % (d.name, n)]
            Pi = true_premium(d, d.q(0.99), 2 * d.q(0.99))
            E = {r: np.array(v[:reps]) / Pi - 1 for r, v in
                 rec['est'].items()}
            rows.append(dict(dist=d.name, n=n, **{
                r: 100 * rmse(E[r]) for r in rules}))
            for r in rules[1:]:
                dd = 100 * (np.abs(E[r]) - np.abs(E['single']))
                h = 1.96 * dd.std(ddof=1) / np.sqrt(len(dd))
                diffs.append(dict(dist=d.name, n=n, rule=r,
                                  mare_diff=dd.mean(), lo=dd.mean() - h,
                                  hi=dd.mean() + h))
            row = dict(dist=d.name, n=n,
                       naive_maxw_over_095=np.mean(np.array(rec['maxw'])
                                                   > 0.95))
            for r in ('single', 'naive', 'tpw', 'equal'):
                lo = np.array(rec['lo'][r][:reps])
                hi = np.array(rec['hi'][r][:reps])
                row[r + '_bias'] = 100 * E[r].mean()
                row[r + '_cov'] = np.mean((lo <= Pi) & (Pi <= hi))
            s2.append(row)
    show(pd.DataFrame(rows), 'TABLE 17  Relative RMSE (%) of the layer '
         'premium (last column: TPW, Supplement S3)',
         'table17_averaging.csv', 1)
    show(pd.DataFrame(diffs), 'TABLE 17 (text)  Mean absolute relative '
         'error minus that of the single threshold (points, 95% interval)',
         'table17_paired_differences.csv', 2)
    show(pd.DataFrame(s2), 'TABLE S2  Bias (%%) and coverage of percentile'
         ' bootstrap intervals (B = %d, weights fixed)' % B,
         'tableS2_bootstrap_fixed_weights.csv', 3)


# ---- Tables S1, S3, Table 16 (rules) and Figure S1 ------------------------
def real_boot_grid(x, qs, R, L, B, rng):
    """Premiums at each grid quantile of the real sample x, and bootstrap
    premiums (B, J) from B resamples reused at every threshold (the
    threshold is re-set at the same sample quantile in each resample)."""
    fits = grid_fit(x, qs, R, L)
    qs2 = [f['q'] for f in fits]
    n = len(x)
    Pb = np.empty((B, len(qs2)))
    for b in range(B):
        xb = x[rng.integers(0, n, n)]
        for j, q in enumerate(qs2):
            u = float(np.quantile(xb, q))
            y = xb[xb > u] - u
            a, be, _ = gpd_fit(y[None, :])
            Pb[b, j] = premium_general(xb, len(y), n, a[0], be[0], u, R, L)
    return fits, np.array([f['Pi'] for f in fits]), Pb


def tpw_real(cfg, quick, fresh):
    """Tables S1 and S3, the TPW premiums of Supplement S2 and S4, and the
    data of Figure S1."""
    B = cfg['B_tpw']
    rng = np.random.default_rng(SEED_TPW_REAL)
    s1, s3, wrows = [], [], []
    sets = [(nm, BENCH[nm], GRID_Q[nm]) for nm in BENCH]
    sets += [(nm, EXTRA[nm], GRID_EXTRA) for nm in EXTRA]
    xl = load('lossalae')
    ql = float(np.quantile(xl, 0.99))
    sets.append(('lossalae', (ql, 2 * ql), GRID_EXTRA))
    for name, (R, L), qs in sets:
        x = load(name)
        n = len(x)
        fits, P, Pb = real_boot_grid(x, qs, R, L, B, rng)
        e_tpw, w_tpw, rho = tpw(P, Pb)
        bma, w_bma = naive_bma(fits)
        xs = np.sort(x)
        single = fit_at_u(x, float(np.quantile(x, THRESHOLD_Q.get(name,
                                                                  0.76))),
                          R, L)
        rule = {}
        for lab, fn in (('Hill plateau', hill_plateau_k),
                        ('MRL linear', mrl_linear_k)):
            k = fn(xs)
            rule[lab] = fit_at_u(x, float(xs[n - k - 1]), R, L)
        for j, f in enumerate(fits):
            wrows.append(dict(dataset=name, q=f['q'], naive_bma=w_bma[j],
                              tpw=w_tpw[j]))
        if name in BENCH:
            s1.append(dict(
                dataset=name, thresholds=len(fits),
                bma_entropy=entropy(w_bma), bma_max_w=w_bma.max(),
                bma_max_q=fits[int(np.argmax(w_bma))]['q'],
                tpw_entropy=entropy(w_tpw), max_entropy=np.log(len(fits)),
                tpw_premium=e_tpw, rho=rho))
        else:
            s3.append(dict(
                dataset=name, tpw_premium=e_tpw, rho=rho,
                single_pct=100 * (single['Pi'] / e_tpw - 1),
                naive_pct=100 * (bma / e_tpw - 1),
                hill_pct=100 * (rule['Hill plateau']['Pi'] / e_tpw - 1),
                mrl_pct=100 * (rule['MRL linear']['Pi'] / e_tpw - 1),
                hill_k=rule['Hill plateau']['k'],
                mrl_k=rule['MRL linear']['k'], single_premium=single['Pi'],
                naive_premium=bma))
        say('    %-15s done' % name)
    x = load('freMTPLsev')
    R, L = EXTRA['freMTPLsev']
    qs = [round(0.80 + 0.02 * i, 2) for i in range(7)]
    fits, P, Pb = real_boot_grid(x, qs, R, L, B, rng)
    say('\nfreMTPLsev, grid 0.80-0.92 (step 0.02): TPW %.1f, single mid-grid'
        ' (q = 0.86) %.1f' % (tpw(P, Pb)[0], P[3]))
    show(pd.DataFrame(s1), 'TABLE S1  Weight entropy, benchmark datasets '
         '(B = %d)' % B, 'tableS1_entropy.csv', 4)
    show(pd.DataFrame(s3), 'TABLE S3  Premiums relative to TPW (%)',
         'tableS3_tpw_additional.csv', 2)
    pd.DataFrame(wrows).to_csv(
        os.path.join(OUT_DIR, 'figureS1_weights.csv'), index=False)


# ---- Table S4 --------------------------------------------------------------
def tableS4_trimmed(cfg, quick, fresh):
    """Table S4: TPW trimmed until rho <= 1, against other rules (retention
    at the true 0.99 quantile, L = 2R, grid 0.60-0.92; Burr and Lomax)."""
    reps, B = cfg['reps_trim'], cfg['B_avg']
    rng = np.random.default_rng(SEED_TRIM)
    rows = []
    for d in (Burr(0.9), Lomax(0.9)):
        for n in (300, 1000):
            R = d.q(0.99)
            L = 2 * R
            Pi = true_premium(d, R, L)
            ks = _ks(n, GRID_SIM)
            mid = len(GRID_SIM) // 2
            E = {r: [] for r in ('single', 'naive', 'tpw', 'tpw_trim',
                                 'equal')}
            for _ in range(reps):
                x = d.rvs(rng, n)
                xs = np.sort(x)[None, :]
                G = fit_grid_rows(xs, ks)
                P = grid_premiums(G, xs, R, L)[0]
                Xb = np.sort(x[rng.integers(0, n, (B, n))], axis=1)
                Gb = fit_grid_rows(Xb, ks)
                Pb = grid_premiums(Gb, Xb, R, L)
                E['single'].append(P[mid])
                E['naive'].append((bma_weights(G['ll'])[0] * P).sum())
                E['tpw'].append(tpw(P, Pb)[0])
                E['tpw_trim'].append(tpw_trimmed(P, Pb))
                E['equal'].append(P.mean())
            rows.append(dict(dist=d.name, n=n, **{
                r: 100 * rmse(np.array(v) / Pi - 1) for r, v in E.items()}))
            say('    %-20s n = %4d done' % (d.name, n))
    show(pd.DataFrame(rows), 'TABLE S4  Trimmed TPW (relative RMSE, %)',
         'tableS4_trimmed_tpw.csv', 1)

# =============================================================================
# 7. SYSTEM CHECK AND RUNNER
# =============================================================================
def _memory_gb():
    """Total and available physical memory in GB (Windows and Linux)."""
    try:
        if platform.system() == 'Windows':
            import ctypes

            class _M(ctypes.Structure):
                _fields_ = [
                    ('dwLength', ctypes.c_ulong),
                    ('dwMemoryLoad', ctypes.c_ulong),
                    ('ullTotalPhys', ctypes.c_ulonglong),
                    ('ullAvailPhys', ctypes.c_ulonglong),
                    ('ullTotalPageFile', ctypes.c_ulonglong),
                    ('ullAvailPageFile', ctypes.c_ulonglong),
                    ('ullTotalVirtual', ctypes.c_ulonglong),
                    ('ullAvailVirtual', ctypes.c_ulonglong),
                    ('ullAvailExtendedVirtual', ctypes.c_ulonglong),
                ]

            m = _M()
            m.dwLength = ctypes.sizeof(_M)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.ullTotalPhys / 2**30, m.ullAvailPhys / 2**30
        info = dict(line.split(':', 1) for line in open('/proc/meminfo'))
        return (
            int(info['MemTotal'].split()[0]) / 2**20,
            int(info['MemAvailable'].split()[0]) / 2**20,
        )
    except Exception:
        return float('nan'), float('nan')


def check():
    """Print Python, package versions and memory."""
    _prepare_folders()
    say('=' * 72)
    say('SYSTEM CHECK  ' + time.strftime('%Y-%m-%d %H:%M:%S'))
    say('Python  : %s  (%s)' % (platform.python_version(), sys.executable))
    say(
        'System  : %s %s, %s'
        % (platform.system(), platform.release(), platform.machine())
    )
    say(
        'Packages: numpy %s, pandas %s, rdata %s'
        % (np.__version__, pd.__version__, getattr(rdata, '__version__', '?'))
    )
    tot, avail = _memory_gb()
    say('Memory  : %.1f GB total, %.1f GB available' % (tot, avail))
    if avail == avail and avail < 1.0:
        say(
            'WARNING : less than 1 GB free - close other programs, or set '
            'GPD_FIT_BATCH = 5_000.'
        )
    say('Folder  : %s' % HERE)
    say('=' * 72)


STEPS = {
    'table2': table2_checks,
    'table3': table3_body,
    'table10': table10_real,
    'table12': table12_subsampling,
    'table9': table9_and_4,
    'table18': table18_bootstrap,
    'table14': table14_16_benchmarks,
    'table11': table11_19_real,
    'table1': table1_data,
    'table7': table7_lomax,
    'table8': table8_beyond,
    'table13': table13_expA,
    'table17': table17_averaging,
    'tpw': tpw_real,
    'tableS4': tableS4_trimmed,
}
ORDER = [
    'table2',
    'table3',
    'table10',
    'table14',
    'table11',
    'table12',
    'table9',
    'table18',
    'table1',
    'table7',
    'table8',
    'table13',
    'table17',
    'tpw',
    'tableS4',
]


def run(quick=True, only=None, fresh=False):
    """Download the data and compute the tables.
    quick=True : small replication counts, to check that everything works (2-3
    min).
    quick=False: the paper's settings and seeds (about 1-4 hours).
    only       : list of steps, e.g. ['table12', 'table18'].
    fresh=True : ignore saved progress and recompute."""
    _prepare_folders()
    check()
    cfg = QUICK if quick else PAPER
    say('Settings: %s  %s' % ('QUICK TEST' if quick else 'PAPER', cfg))
    with open(
        os.path.join(OUT_DIR, 'all_tables.txt'), 'w', encoding='utf8'
    ) as f:
        f.write(
            'Results (%s settings), %s\n'
            % ('quick' if quick else 'paper', time.strftime('%Y-%m-%d %H:%M'))
        )
    try:
        download_data()
    except Exception as e:
        say('!!! DATA DOWNLOAD FAILED: %s' % e)
        return {}
    status = {}
    t_all = time.time()
    for name in only or ORDER:
        say('\n' + '-' * 72)
        say('%s  started %s' % (name.upper(), time.strftime('%H:%M:%S')))
        t0 = time.time()
        try:
            STEPS[name](cfg, quick, fresh)
            status[name] = 'OK'
            say(
                '%s  finished in %.1f min'
                % (name.upper(), (time.time() - t0) / 60)
            )
        except MemoryError:
            status[name] = 'FAILED (out of memory)'
            say(
                '!!! %s: OUT OF MEMORY. Close other programs or lower '
                'GPD_FIT_BATCH; then run again '
                '(saved progress is kept).' % name
            )
        except Exception as e:
            status[name] = 'FAILED'
            say('!!! %s FAILED: %s: %s' % (name, type(e).__name__, e))
            say(traceback.format_exc())
        gc.collect()
    say('\n' + '=' * 72)
    say(
        'SUMMARY (%.1f min): %s'
        % (
            (time.time() - t_all) / 60,
            ', '.join('%s %s' % kv for kv in status.items()),
        )
    )
    say('Tables in: %s' % OUT_DIR)
    say('=' * 72)
    return status


# =============================================================================
# 8. START HERE when the file is run (python xol_tables.py [--paper] [--only
# ...] [--fresh])
# =============================================================================
if __name__ == '__main__':
    args = sys.argv[1:]
    only = None
    if '--only' in args:
        only = [
            a
            for a in args[args.index('--only') + 1 :]
            if not a.startswith('-')
        ] or None
        bad = [a for a in (only or []) if a not in STEPS]
        if bad:
            sys.exit(
                'Unknown step(s) %s. Choose from: %s' % (bad, ', '.join(ORDER))
            )
    run(quick='--paper' not in args, only=only, fresh='--fresh' in args)
