# =============================================================================
# make_paper_figures_4_5.py - draws Figures 4, 5 and S2 of the paper
#
# Figure 4 : premium at each threshold of the three benchmark datasets,
#            with bootstrap standard-error bars, naive BMA and equal weight.
# Figure 5 : premium at each threshold of the seven additional datasets,
#            relative to the median, with 90% bootstrap bands.
# Figure S2: the ES multiplier 1/(1 - xi) against xi (online supplement).
#
# INPUT: xol_out/real_grid_bootstrap.csv, written by
#        python xol_tables.py --paper --only table11
#        (this figure script does no fitting of its own).
# Output: folder paper_figures/ with .png, .pdf, .eps and .tif (300 dpi,
# black and white). Needs numpy, pandas, matplotlib and pillow.
#
# HOW TO RUN
#   Jupyter: paste this whole file into ONE cell and run it.
#   Terminal: python make_paper_figures_4_5.py
#
# CRASH-PROOF: the drawing is done in a separate Python process, so a crash
# in a compiled library cannot stop the Jupyter kernel.
# =============================================================================
import os
import sys
import subprocess

for _v in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[_v] = '1'
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['MPLBACKEND'] = 'Agg'

SCRIPT_NAME = 'make_paper_figures_4_5.py'
OUT_NAME = 'paper_figures'
CSV_PATH = os.path.join('xol_out', 'real_grid_bootstrap.csv')

BENCH_LABEL = {
    'Secura': ('Secura', 'EUR thousand', 1e-3),
    'Danish': ('Danish', 'DKK million', 1.0),
    'Norwegian 1988': ('Norwegian 1988', 'NOK thousand', 1.0),
}
EXTRA_ORDER = ['freMTPL2sev', 'freMTPLsev', 'fremarine', 'usautoBI',
               'frecomfire', 'frebiloss', 'ausautoBI8999']


def _script_path():
    """Path of this code as a file. If it was pasted into a notebook cell,
    save the cell's code as a file first, so it can run in its own process."""
    try:
        return os.path.abspath(__file__)
    except NameError:
        pass
    try:
        cell = get_ipython().user_ns['In'][-1]          # this cell's code
    except Exception:
        return None
    lines = [ln for ln in cell.splitlines()
             if not ln.startswith(('%', '!'))]
    path = os.path.join(os.getcwd(), SCRIPT_NAME)
    with open(path, 'w', encoding='utf8') as f:
        f.write('\n'.join(lines) + '\n')
    return path


# =============================================================================
# PART A - runs in the child process
# =============================================================================
def _save(fig, out_dir, name, plt):
    """Save only the figure and format this child process was asked for."""
    if name == _ONLY[0]:
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, name + '.' + _ONLY[1])
        fig.savefig(path, dpi=300)
        print('saved', path, flush=True)
    plt.close(fig)


def draw(out_dir, csv_path):
    import faulthandler
    faulthandler.enable()
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    d = pd.read_csv(csv_path)
    plt.rcParams.update({
        'font.family': 'serif', 'font.size': 8.5, 'axes.titlesize': 9,
        'legend.fontsize': 7.5, 'xtick.labelsize': 7.5,
        'ytick.labelsize': 7.5, 'axes.spines.top': False,
        'axes.spines.right': False, 'axes.linewidth': 0.6,
        'lines.linewidth': 1.2, 'legend.frameon': False,
        'savefig.bbox': 'tight', 'savefig.pad_inches': 0.03,
        'ps.fonttype': 42, 'pdf.fonttype': 42})
    mk = dict(marker='o', ms=3.5, color='0.0', markerfacecolor='white',
              markeredgewidth=0.9)

    # ---- Figure 4: benchmark datasets -----------------------------------
    fig, axes = plt.subplots(1, 3, figsize=(6.5, 2.4))
    for ax, (name, (title, unit, sc)) in zip(axes, BENCH_LABEL.items()):
        g = d[d.dataset == name].sort_values('q')
        ax.errorbar(g.q, g.Pi * sc, yerr=g.boot_se * sc, ecolor='0.55',
                    elinewidth=0.7, capsize=1.5, lw=1.0,
                    label=r'Single threshold $\pm$ 1 bootstrap SE', **mk)
        ax.axhline(g.naive_bma.iloc[0] * sc, color='0.0', ls='--', lw=0.9,
                   label='Naive BMA')
        ax.axhline(g.equal_weight.iloc[0] * sc, color='0.0', ls=':',
                   lw=1.1, label='Equal weight')
        ax.set_title('%s (%s)' % (title, unit), loc='left')
        ax.set_xlabel('Threshold quantile $q$')
        ax.grid(axis='y', color='0.9', lw=0.5)
        ax.set_axisbelow(True)
    axes[0].set_ylabel(r'Layer premium $\hat{\Pi}$')
    axes[0].legend(loc='upper center', bbox_to_anchor=(1.75, -0.28),
                   ncol=3)
    fig.tight_layout(w_pad=1.5)
    _save(fig, out_dir, 'Figure4', plt)

    # ---- Figure 5: additional datasets ----------------------------------
    fig, axes = plt.subplots(2, 4, figsize=(6.5, 3.9))
    axes = axes.ravel()
    for ax, name in zip(axes, EXTRA_ORDER):
        g = d[d.dataset == name].sort_values('q')
        m = np.median(g.Pi)
        ax.fill_between(g.q, g.boot_q05 / m, g.boot_q95 / m, color='0.85',
                        lw=0, label='90% bootstrap band')
        ax.plot(g.q, g.Pi / m, lw=1.0, label='Single threshold', **mk)
        ax.axhline(g.naive_bma.iloc[0] / m, color='0.0', ls='--', lw=0.9,
                   label='Naive BMA')
        ax.axhline(g.equal_weight.iloc[0] / m, color='0.0', ls=':', lw=1.1,
                   label='Equal weight')
        ax.set_title(name, loc='left')
        ax.set_xticks([0.6, 0.7, 0.8, 0.9])
        ax.grid(axis='y', color='0.9', lw=0.5)
        ax.set_axisbelow(True)
    for ax in axes[4:]:
        ax.set_xlabel('Threshold quantile')
    for ax in (axes[0], axes[4]):
        ax.set_ylabel('Premium / median')
    h, lab = axes[0].get_legend_handles_labels()
    axes[7].axis('off')
    axes[7].legend(h, lab, loc='center')
    fig.tight_layout()
    _save(fig, out_dir, 'Figure5', plt)

    # ---- Figure S2: ES multiplier ---------------------------------------
    fig, ax = plt.subplots(figsize=(6.5, 2.8))
    xs = np.linspace(-0.3, 0.995, 600)
    ax.plot(xs, np.minimum(1.0 / (1.0 - xs), 50), color='0.0',
            label=r'ES multiplier $1/(1-\hat{\xi})$')
    ax.axvline(1.0, color='0.4', ls=':', lw=0.8)
    ax.text(0.95, 45, r'ES undefined for $\hat{\xi} \geq 1$ $\rightarrow$',
            fontsize=7.5, ha='right')
    marks = ['o', 's', '^']
    for (name, (title, _, _)), mm in zip(BENCH_LABEL.items(), marks):
        x = d[d.dataset == name].xi.max()
        ax.plot([x], [1 / (1 - x)], marker=mm, ls='none', ms=5,
                color='0.0', markerfacecolor='white',
                label=r'%s: highest $\hat{\xi}$ = %.2f' % (title, x))
    ax.set_xlim(-0.3, 1.3)
    ax.set_ylim(0, 50)
    ax.set_xlabel(r'Shape parameter $\hat{\xi}$')
    ax.set_ylabel('ES multiplier (capped at 50)')
    ax.legend(loc='upper left')
    fig.tight_layout()
    _save(fig, out_dir, 'FigureS2', plt)


# =============================================================================
# PART B - the main run
# =============================================================================
def main():
    script = _script_path()
    if script is None:
        print('Could not save this code as a file. Save it as '
              + SCRIPT_NAME + ' and run:  !python ' + SCRIPT_NAME)
        return
    here = os.path.dirname(script)
    csv_path = os.path.join(here, CSV_PATH)
    if not os.path.exists(csv_path):
        print('Missing %s. First run:  python xol_tables.py --paper '
              '--only table11' % csv_path)
        return
    out_dir = os.path.join(here, OUT_NAME)
    print('Drawing Figures 4, 5 and S2 into', out_dir, flush=True)
    names = ('Figure4', 'Figure5', 'FigureS2')
    failed = _run_all(script, out_dir, csv_path, names)
    _finish(script, out_dir, names, failed, 'Figures 4, 5 and S2')


# =============================================================================
# TIFF FILES - made from the saved PNG files in a separate process
# =============================================================================
# The TIFF files are written uncompressed by Pillow's own encoder, which does
# not use the compiled libtiff library (its LZW compression crashed with exit
# code 0xC0000409 on some Windows PCs). Because this runs in its own process,
# a failure here cannot affect the PNG, PDF and EPS files already saved.
def _png_to_tif(pairs):
    """pairs: [png_1, tif_1, png_2, tif_2, ...]"""
    from PIL import Image
    for png, tif in zip(pairs[0::2], pairs[1::2]):
        os.makedirs(os.path.dirname(tif), exist_ok=True)
        with Image.open(png) as im:
            im.convert('L').save(tif, format='TIFF', dpi=(300, 300))
        print('  saved', tif, flush=True)


def _make_tifs(script, pairs):
    """Run _png_to_tif in a child process; True if all TIFFs were saved."""
    if not pairs:
        return True
    r = subprocess.run([sys.executable, script, '--tif'] + list(pairs),
                       capture_output=True, text=True,
                       encoding='utf8', errors='replace')
    print(r.stdout, end='', flush=True)
    if r.returncode != 0:
        print('  !!! TIFF files not made (exit code %s). The PNG, PDF and EPS'
              ' files are complete; EPS is accepted for print.'
              % r.returncode)
        for line in r.stderr.strip().splitlines()[-8:]:
            print('      ' + line)
        return False
    return True


# =============================================================================
# ONE PROCESS PER FILE - each figure in each format is drawn by its own short
# Python process. On some Windows PCs the compiled drawing libraries abort
# (exit code 0xC0000409) when a process goes on drawing after a file has been
# saved; with one file per process, nothing runs after a save, and a failure
# in one file cannot stop the others.
# =============================================================================
_ONLY = [None, None]          # set in the child: (figure name, format)


def _run_all(script, out_dir, in_arg, names):
    """Draw every figure in PNG, PDF and EPS, one process per file.
    Returns the list of files that could not be saved."""
    failed = []
    for n in names:
        for ext in ('png', 'pdf', 'eps'):
            path = os.path.join(out_dir, n + '.' + ext)
            if os.path.exists(path):
                os.remove(path)
            r = subprocess.run(
                [sys.executable, script, '--draw', out_dir, in_arg, n, ext],
                capture_output=True, text=True, encoding='utf8',
                errors='replace')
            # The child prints "saved <path>" only after the file is closed.
            done = ('saved ' + path) in r.stdout and os.path.exists(path)
            if done:
                note = '' if r.returncode == 0 else (
                    '   (process then ended with code %s; file complete)'
                    % r.returncode)
                print('  saved', path + note, flush=True)
            else:
                failed.append(path)
                print('  !!! %s NOT saved (exit code %s)'
                      % (path, r.returncode), flush=True)
                for line in r.stderr.strip().splitlines()[-6:]:
                    print('      ' + line[:200])
    return failed


def _finish(script, out_dir, names, failed, label):
    pairs = []
    for n in names:
        png = os.path.join(out_dir, n + '.png')
        if os.path.exists(png):
            pairs += [png, png[:-4] + '.tif']
    tif_ok = _make_tifs(script, pairs)
    if failed:
        print('PARTLY DONE: %d file(s) not saved (listed above).'
              % len(failed))
    else:
        print('DONE: %s saved as PNG, PDF, EPS%s.'
              % (label, ' and TIFF' if tif_ok else ''))
    try:                                   # preview below the notebook cell
        get_ipython()
        from IPython.display import Image, display
        for n in names:
            png = os.path.join(out_dir, n + '.png')
            if os.path.exists(png):
                display(Image(filename=png, width=800))
    except Exception:
        pass


if __name__ == '__main__':
    if '--tif' in sys.argv:                # child process: TIFF files
        _png_to_tif(sys.argv[sys.argv.index('--tif') + 1 :])
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)
    elif '--draw' in sys.argv:             # child process
        i = sys.argv.index('--draw')
        _ONLY[:] = [sys.argv[i + 3], sys.argv[i + 4]]
        draw(sys.argv[i + 1], sys.argv[i + 2])
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)      # skip the shutdown clean-up that crashes on some PCs
    else:
        main()
